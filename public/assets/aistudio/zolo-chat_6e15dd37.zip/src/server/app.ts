import crypto from 'node:crypto';
import express, { type Request, type Response, type NextFunction } from 'express';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import multer from 'multer';
import type { CountryCode } from 'libphonenumber-js';
import {
  AppDomainError,
  SESSION_DURATION_MS,
  changeAccountPassword,
  changePhoneNumberDirect,
  checkDatabaseHealth,
  linkFirebaseGoogleForRecovery,
  listActiveSessionsForUser,
  loginUserByMobile,
  permanentlyDeleteAccount,
  recoverAccountDirect,
  registerUserDirect,
  revokeAllSessionsForUser,
  revokeSingleSession,
  saveUserChatState,
  toPublicUser,
  updateUserProfileRecord,
} from '../db/repository.ts';
import {
  type DirectMessageDto,
  type MessageRichPayload,
  deleteDirectMessageInDb,
  fetchUserDirectMessagesAndPeers,
  lookupRegisteredUsersByPhones,
  markConversationReadInDb,
  markUndeliveredMessagesDelivered,
  saveDirectMessage,
  searchRegisteredUsers,
  toggleMessageReactionInDb,
  voteMessagePollInDb,
} from '../db/messagingRepository.ts';
import {
  createStatusStoryInDb,
  fetchUserCallHistory,
  fetchVisibleStatusStories,
  markMissedCallsSeenInDb,
  markStatusStoryViewedInDb,
} from '../db/statusAndCallsRepository.ts';
import {
  type AuthenticatedRequest,
  SESSION_COOKIE_NAME,
  requireSessionAuth,
  verifyOptionalFirebaseIdToken,
} from '../middleware/auth.ts';
import { isSupabaseConfigured } from '../lib/supabaseServer.ts';
import { normalizeAndValidatePhone } from './phoneUtils.ts';
import { realtimeHub } from './realtimeHub.ts';
import {
  MAX_AVATAR_BYTES,
  getStoredMediaByKey,
  isS3Configured,
  storeProfilePicture,
} from './storageService.ts';

export interface CreateAppOptions {
  disableRateLimit?: boolean;
}

function setSessionCookie(req: Request, res: Response, token: string): void {
  const isHttps =
    req.secure ||
    req.headers['x-forwarded-proto'] === 'https' ||
    process.env.NODE_ENV === 'production';

  res.cookie(SESSION_COOKIE_NAME, token, {
    httpOnly: true,
    secure: isHttps,
    sameSite: isHttps ? 'none' : 'lax',
    maxAge: SESSION_DURATION_MS,
    path: '/',
    ...(isHttps ? ({ partitioned: true } as Record<string, unknown>) : {}),
  });
}

function clearSessionCookie(req: Request, res: Response): void {
  const isHttps =
    req.secure ||
    req.headers['x-forwarded-proto'] === 'https' ||
    process.env.NODE_ENV === 'production';

  res.clearCookie(SESSION_COOKIE_NAME, {
    httpOnly: true,
    secure: isHttps,
    sameSite: isHttps ? 'none' : 'lax',
    path: '/',
  });
}

function parseSavedChatState(rawJson: string | null): unknown {
  if (!rawJson) return null;
  try {
    return JSON.parse(rawJson);
  } catch {
    return null;
  }
}

export function createApp(options: CreateAppOptions = {}) {
  const app = express();
  app.set('trust proxy', 1);

  app.use(
    helmet({
      contentSecurityPolicy: false,
      crossOriginEmbedderPolicy: false,
      crossOriginResourcePolicy: { policy: 'cross-origin' },
      frameguard: false,
    })
  );

  const allowedOrigins = process.env.CORS_ORIGIN
    ? process.env.CORS_ORIGIN.split(',').map((o) => o.trim()).filter(Boolean)
    : null;

  app.use(
    cors({
      origin: allowedOrigins && allowedOrigins.length > 0 ? allowedOrigins : true,
      credentials: true,
    })
  );

  app.use(cookieParser());
  app.use(express.json({ limit: '12mb' }));

  const noopMiddleware = (_req: Request, _res: Response, next: NextFunction) => next();

  const authActionLimiter = options.disableRateLimit
    ? noopMiddleware
    : rateLimit({
        windowMs: 15 * 60 * 1000,
        max: 60,
        standardHeaders: true,
        legacyHeaders: false,
        message: {
          code: 'RATE_LIMITED',
          error: 'Too many authentication attempts. Please wait a few minutes and try again.',
        },
      });

  const avatarUpload = multer({
    storage: multer.memoryStorage(),
    limits: {
      fileSize: MAX_AVATAR_BYTES,
      files: 1,
    },
  });

  // 1. Health & Database Connectivity Check
  app.get('/api/health', async (_req: Request, res: Response) => {
    try {
      const dbStatus = await checkDatabaseHealth();
      res.status(200).json({
        status: 'ok',
        database: 'connected',
        databaseProvider: dbStatus.provider,
        supabaseConfigured: isSupabaseConfigured(),
        storageDriver: isS3Configured()
          ? 's3'
          : isSupabaseConfigured()
          ? 'supabase'
          : 'postgresql-persistent',
        timestamp: new Date().toISOString(),
      });
    } catch (error: unknown) {
      const msg = error instanceof Error ? error.message : 'Health check failed';
      res.status(503).json({
        status: 'degraded',
        database: 'unavailable',
        error: msg,
        timestamp: new Date().toISOString(),
      });
    }
  });

  // 2. Upload Profile Picture
  app.post(
    '/api/upload/avatar',
    authActionLimiter,
    (req: Request, res: Response, next: NextFunction) => {
      avatarUpload.single('avatar')(req, res, (err: unknown) => {
        if (err instanceof multer.MulterError) {
          if (err.code === 'LIMIT_FILE_SIZE') {
            res.status(400).json({
              code: 'FILE_TOO_LARGE',
              error: 'Profile picture must be 5 MB or smaller.',
            });
            return;
          }
          res.status(400).json({ code: 'UPLOAD_ERROR', error: err.message });
          return;
        }
        if (err) {
          res.status(400).json({ code: 'UPLOAD_ERROR', error: 'Invalid file upload.' });
          return;
        }
        next();
      });
    },
    async (req: Request, res: Response) => {
      try {
        if (!req.file || !req.file.buffer) {
          res.status(400).json({
            code: 'NO_FILE',
            error: 'Please select a JPG, PNG, or WebP image to upload.',
          });
          return;
        }

        const stored = await storeProfilePicture(req.file.buffer);
        res.status(201).json({
          url: stored.url,
          mimeType: stored.mimeType,
          byteSize: stored.byteSize,
          storageDriver: stored.storageDriver,
        });
      } catch (error: unknown) {
        const message =
          error instanceof Error ? error.message : 'Failed to upload profile picture.';
        res.status(400).json({
          code: 'INVALID_IMAGE',
          error: message,
        });
      }
    }
  );

  // 3. Serve Persistent Media Objects
  app.get('/api/media/:objectKey', async (req: Request, res: Response) => {
    try {
      const objectKey = String(req.params.objectKey || '').replace(/[^a-zA-Z0-9._-]/g, '');
      if (!objectKey) {
        res.status(400).json({ error: 'Invalid media key.' });
        return;
      }

      const media = await getStoredMediaByKey(objectKey);
      if (!media) {
        res.status(404).json({ error: 'Media not found.' });
        return;
      }

      res.setHeader('Content-Type', media.mimeType);
      res.setHeader('Content-Length', String(media.buffer.length));
      res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
      res.setHeader('Content-Security-Policy', "default-src 'none'");
      res.status(200).send(media.buffer);
    } catch {
      res.status(500).json({ error: 'Failed to load image.' });
    }
  });

  // 4. Direct Lifetime Account Signup (Mobile Number + Password)
  app.post('/api/auth/signup', authActionLimiter, async (req: Request, res: Response) => {
    try {
      const {
        fullName,
        phone,
        countryIso = 'IN',
        dialCode = '+91',
        password,
        avatarUrl,
      } = req.body as {
        fullName?: string;
        phone?: string;
        countryIso?: string;
        dialCode?: string;
        password?: string;
        avatarUrl?: string | null;
      };

      const trimmedName = (fullName || '').trim();
      if (trimmedName.length < 2 || trimmedName.length > 80) {
        res.status(400).json({
          code: 'INVALID_NAME',
          error: 'Full name must be between 2 and 80 characters.',
        });
        return;
      }

      const rawPassword = typeof password === 'string' ? password : '';
      if (rawPassword.length < 6 || rawPassword.length > 128) {
        res.status(400).json({
          code: 'INVALID_PASSWORD',
          error: 'Password must be at least 6 characters long.',
        });
        return;
      }

      const normalizedPhone = normalizeAndValidatePhone(
        phone || '',
        (countryIso || 'IN') as CountryCode,
        dialCode
      );
      if (!normalizedPhone.valid || !normalizedPhone.e164) {
        res.status(400).json({
          code: 'INVALID_PHONE',
          error: normalizedPhone.error || 'Please enter a valid mobile number.',
        });
        return;
      }

      const safeAvatarUrl =
        typeof avatarUrl === 'string' && avatarUrl.trim().length > 0
          ? avatarUrl.trim()
          : null;

      const { user, rawSessionToken, recoveryKey } = await registerUserDirect({
        phoneNormalized: normalizedPhone.e164,
        countryCode: normalizedPhone.countryCallingCode || dialCode,
        fullName: trimmedName,
        password: rawPassword,
        avatarUrl: safeAvatarUrl,
        userAgent: req.headers['user-agent'],
        ipAddress: req.ip,
      });

      setSessionCookie(req, res, rawSessionToken);

      res.status(201).json({
        user: toPublicUser(user),
        sessionToken: rawSessionToken,
        recoveryKey,
        chatState: null,
      });
    } catch (error: unknown) {
      if (error instanceof AppDomainError) {
        res.status(error.statusCode).json({
          code: error.code,
          error: error.message,
        });
        return;
      }
      console.error('Error in POST /api/auth/signup:', error);
      res.status(500).json({
        code: 'SIGNUP_FAILED',
        error: 'Unable to complete signup right now. Please try again.',
      });
    }
  });

  // 5. Login with Mobile Number & Password
  app.post('/api/auth/login', authActionLimiter, async (req: Request, res: Response) => {
    try {
      const {
        phone,
        countryIso = 'IN',
        dialCode = '+91',
        password,
      } = req.body as {
        phone?: string;
        countryIso?: string;
        dialCode?: string;
        password?: string;
      };

      const normalizedPhone = normalizeAndValidatePhone(
        phone || '',
        (countryIso || 'IN') as CountryCode,
        dialCode
      );
      if (!normalizedPhone.valid || !normalizedPhone.e164) {
        res.status(400).json({
          code: 'INVALID_PHONE',
          error: normalizedPhone.error || 'Please enter a valid mobile number.',
        });
        return;
      }

      const rawPassword = typeof password === 'string' ? password : '';
      if (rawPassword.length < 6) {
        res.status(400).json({
          code: 'PASSWORD_REQUIRED',
          error: 'Please enter your account password (minimum 6 characters).',
        });
        return;
      }

      const { user, rawSessionToken } = await loginUserByMobile({
        phoneNormalized: normalizedPhone.e164,
        password: rawPassword,
        userAgent: req.headers['user-agent'],
        ipAddress: req.ip,
      });

      setSessionCookie(req, res, rawSessionToken);

      res.status(200).json({
        user: toPublicUser(user),
        sessionToken: rawSessionToken,
        chatState: parseSavedChatState(user.chatStateJson),
      });
    } catch (error: unknown) {
      if (error instanceof AppDomainError) {
        res.status(error.statusCode).json({
          code: error.code,
          error: error.message,
        });
        return;
      }
      console.error('Error in POST /api/auth/login:', error);
      res.status(500).json({
        code: 'LOGIN_FAILED',
        error: 'Unable to log in right now. Please try again.',
      });
    }
  });

  // 6. Safe Account & Password Recovery
  app.post('/api/auth/recover', authActionLimiter, async (req: Request, res: Response) => {
    try {
      const {
        oldPhone,
        oldCountryIso = 'IN',
        oldDialCode = '+91',
        recoveryKey,
        firebaseIdToken,
        newPhone,
        newCountryIso = 'IN',
        newDialCode = '+91',
        newPassword,
      } = req.body as {
        oldPhone?: string;
        oldCountryIso?: string;
        oldDialCode?: string;
        recoveryKey?: string;
        firebaseIdToken?: string;
        newPhone?: string;
        newCountryIso?: string;
        newDialCode?: string;
        newPassword?: string;
      };

      const oldNorm = normalizeAndValidatePhone(
        oldPhone || '',
        (oldCountryIso || 'IN') as CountryCode,
        oldDialCode
      );
      const effectiveNewPhone = (newPhone || '').trim() ? newPhone || '' : oldPhone || '';
      const effectiveNewIso = (newPhone || '').trim() ? newCountryIso : oldCountryIso;
      const effectiveNewDial = (newPhone || '').trim() ? newDialCode : oldDialCode;

      const newNorm = normalizeAndValidatePhone(
        effectiveNewPhone,
        (effectiveNewIso || 'IN') as CountryCode,
        effectiveNewDial
      );

      if (!oldNorm.valid || !oldNorm.e164 || !newNorm.valid || !newNorm.e164) {
        res.status(400).json({
          code: 'INVALID_PHONE',
          error: 'Please enter valid mobile number(s).',
        });
        return;
      }

      if (newPassword !== undefined && newPassword.length > 0 && newPassword.length < 6) {
        res.status(400).json({
          code: 'INVALID_PASSWORD',
          error: 'New password must be at least 6 characters long.',
        });
        return;
      }

      const decodedFirebase = await verifyOptionalFirebaseIdToken(firebaseIdToken);
      if (!recoveryKey?.trim() && !decodedFirebase?.uid) {
        res.status(401).json({
          code: 'RECOVERY_CREDENTIALS_REQUIRED',
          error:
            'Provide your ZOLO Recovery Key or sign in with your linked Google recovery account.',
        });
        return;
      }

      const { user, rawSessionToken, newRecoveryKey } = await recoverAccountDirect({
        oldPhoneNormalized: oldNorm.e164,
        recoveryKey: recoveryKey?.trim(),
        verifiedFirebaseUid: decodedFirebase?.uid,
        newPhoneNormalized: newNorm.e164,
        newCountryCode: newNorm.countryCallingCode || effectiveNewDial,
        newPassword: newPassword && newPassword.length >= 6 ? newPassword : undefined,
        userAgent: req.headers['user-agent'],
        ipAddress: req.ip,
      });

      setSessionCookie(req, res, rawSessionToken);

      res.status(200).json({
        user: toPublicUser(user),
        sessionToken: rawSessionToken,
        recoveryKey: newRecoveryKey,
        chatState: parseSavedChatState(user.chatStateJson),
      });
    } catch (error: unknown) {
      if (error instanceof AppDomainError) {
        res.status(error.statusCode).json({
          code: error.code,
          error: error.message,
        });
        return;
      }
      console.error('Error in POST /api/auth/recover:', error);
      res.status(500).json({
        code: 'RECOVERY_FAILED',
        error: 'Unable to recover account right now.',
      });
    }
  });

  // 7. Get Current Authenticated Account
  app.get('/api/account/me', requireSessionAuth, (req: AuthenticatedRequest, res: Response) => {
    const user = req.authUser!;
    res.json({
      user: toPublicUser(user),
      currentSessionId: req.authSession!.sessionId,
      chatState: parseSavedChatState(user.chatStateJson),
    });
  });

  // 8. Update User Profile
  app.patch(
    '/api/account/profile',
    requireSessionAuth,
    async (req: AuthenticatedRequest, res: Response) => {
      try {
        const { fullName, about, avatarUrl } = req.body as {
          fullName?: string;
          about?: string;
          avatarUrl?: string | null;
        };

        if (fullName !== undefined && (fullName.trim().length < 2 || fullName.trim().length > 80)) {
          res.status(400).json({
            code: 'INVALID_NAME',
            error: 'Full name must be between 2 and 80 characters.',
          });
          return;
        }

        const updated = await updateUserProfileRecord(req.authUser!.id, {
          fullName,
          about,
          avatarUrl,
        });

        res.json({ user: toPublicUser(updated) });
      } catch (error: unknown) {
        if (error instanceof AppDomainError) {
          res.status(error.statusCode).json({ code: error.code, error: error.message });
          return;
        }
        res.status(500).json({ code: 'PROFILE_UPDATE_FAILED', error: 'Failed to update profile.' });
      }
    }
  );

  // 9. Change Mobile Number Directly
  app.post(
    '/api/account/phone/change',
    requireSessionAuth,
    async (req: AuthenticatedRequest, res: Response) => {
      try {
        const {
          newPhone,
          countryIso = 'IN',
          dialCode = '+91',
        } = req.body as {
          newPhone?: string;
          countryIso?: string;
          dialCode?: string;
        };

        const normalized = normalizeAndValidatePhone(
          newPhone || '',
          (countryIso || 'IN') as CountryCode,
          dialCode
        );
        if (!normalized.valid || !normalized.e164) {
          res.status(400).json({
            code: 'INVALID_PHONE',
            error: normalized.error || 'Please enter a valid new mobile number.',
          });
          return;
        }

        const updatedUser = await changePhoneNumberDirect({
          userId: req.authUser!.id,
          currentSessionId: req.authSession!.sessionId,
          newPhoneNormalized: normalized.e164,
          newCountryCode: normalized.countryCallingCode || dialCode,
        });

        res.json({ user: toPublicUser(updatedUser) });
      } catch (error: unknown) {
        if (error instanceof AppDomainError) {
          res.status(error.statusCode).json({ code: error.code, error: error.message });
          return;
        }
        res.status(500).json({
          code: 'PHONE_CHANGE_FAILED',
          error: 'Failed to update mobile number.',
        });
      }
    }
  );

  // 10. Link Google Account for Recovery
  app.post(
    '/api/account/link-google',
    requireSessionAuth,
    async (req: AuthenticatedRequest, res: Response) => {
      try {
        const { firebaseIdToken } = req.body as { firebaseIdToken?: string };
        const decoded = await verifyOptionalFirebaseIdToken(firebaseIdToken);
        if (!decoded) {
          res.status(401).json({
            code: 'INVALID_GOOGLE_TOKEN',
            error: 'Could not verify Google authentication token.',
          });
          return;
        }

        const updated = await linkFirebaseGoogleForRecovery({
          userId: req.authUser!.id,
          firebaseUid: decoded.uid,
          email: decoded.email ?? null,
        });

        res.json({ user: toPublicUser(updated) });
      } catch (error: unknown) {
        if (error instanceof AppDomainError) {
          res.status(error.statusCode).json({ code: error.code, error: error.message });
          return;
        }
        res.status(500).json({
          code: 'GOOGLE_LINK_FAILED',
          error: 'Failed to link Google recovery account.',
        });
      }
    }
  );

  // 11. Sync Persistent Chat State
  app.put(
    '/api/account/chat-state',
    requireSessionAuth,
    async (req: AuthenticatedRequest, res: Response) => {
      try {
        const { chatState } = req.body as { chatState?: unknown };
        if (!chatState || typeof chatState !== 'object') {
          res
            .status(400)
            .json({ code: 'INVALID_CHAT_STATE', error: 'Invalid chat state payload.' });
          return;
        }
        await saveUserChatState(req.authUser!.id, JSON.stringify(chatState));
        res.json({ saved: true });
      } catch {
        res.status(500).json({ code: 'CHAT_SYNC_FAILED', error: 'Failed to save chat state.' });
      }
    }
  );

  // =========================================================================
  // REAL ZOLO CONTACT DISCOVERY & REAL USER-TO-USER MESSAGING ENDPOINTS
  // =========================================================================

  // 12. Look up a mobile number (or batch of numbers) to check ZOLO registration & live presence
  app.post(
    '/api/contacts/lookup',
    requireSessionAuth,
    async (req: AuthenticatedRequest, res: Response) => {
      try {
        const {
          phone,
          countryIso = 'IN',
          dialCode = '+91',
          phones,
        } = req.body as {
          phone?: string;
          countryIso?: string;
          dialCode?: string;
          phones?: string[];
        };

        // Batch lookup mode
        if (Array.isArray(phones)) {
          const normalizedMap = new Map<string, string>();
          for (const raw of phones) {
            const norm = normalizeAndValidatePhone(
              String(raw || ''),
              (countryIso || 'IN') as CountryCode,
              dialCode
            );
            if (norm.valid && norm.e164) {
              normalizedMap.set(raw, norm.e164);
            }
          }

          const uniqueE164 = Array.from(new Set(normalizedMap.values()));
          const profiles = await lookupRegisteredUsersByPhones(uniqueE164);
          const profileByPhone = new Map(profiles.map((p) => [p.phoneNormalized, p]));

          const results = uniqueE164.map((e164) => {
            const prof = profileByPhone.get(e164) || null;
            const presence = realtimeHub.getPresence(e164);
            return {
              phoneNormalized: e164,
              isRegistered: Boolean(prof),
              user: prof,
              online: prof ? presence.online : false,
              lastSeen: prof ? presence.lastSeen : 'Not registered on ZOLO yet',
            };
          });

          res.json({ contacts: results });
          return;
        }

        // Single phone lookup mode
        const norm = normalizeAndValidatePhone(
          phone || '',
          (countryIso || 'IN') as CountryCode,
          dialCode
        );
        if (!norm.valid || !norm.e164) {
          res.status(400).json({
            code: 'INVALID_PHONE',
            error: norm.error || 'Please enter a valid mobile number.',
          });
          return;
        }

        const profiles = await lookupRegisteredUsersByPhones([norm.e164]);
        const found = profiles[0] || null;
        const presence = realtimeHub.getPresence(norm.e164);

        res.json({
          phoneNormalized: norm.e164,
          isRegistered: Boolean(found),
          user: found,
          online: found ? presence.online : false,
          lastSeen: found ? presence.lastSeen : 'Invite or message — delivers when they join ZOLO',
        });
      } catch (error) {
        console.error('Error in POST /api/contacts/lookup:', error);
        res.status(500).json({
          code: 'CONTACT_LOOKUP_FAILED',
          error: 'Could not look up mobile number.',
        });
      }
    }
  );

  // 13. Search registered ZOLO users by mobile number or name
  app.get(
    '/api/contacts/search',
    requireSessionAuth,
    async (req: AuthenticatedRequest, res: Response) => {
      try {
        const q = String(req.query.q || '').trim();
        if (q.length < 2) {
          res.json({ users: [] });
          return;
        }

        const matches = await searchRegisteredUsers(q, req.authUser!.phoneNormalized);
        const enriched = matches.map((u) => {
          const presence = realtimeHub.getPresence(u.phoneNormalized);
          return {
            ...u,
            online: presence.online,
            lastSeen: presence.lastSeen,
          };
        });

        res.json({ users: enriched });
      } catch (error) {
        console.error('Error in GET /api/contacts/search:', error);
        res.status(500).json({ code: 'SEARCH_FAILED', error: 'Failed to search ZOLO directory.' });
      }
    }
  );

  // 14. Fetch User's Real Direct Message Inbox & Mark Newly Received Messages Delivered
  app.get(
    '/api/messages/inbox',
    requireSessionAuth,
    async (req: AuthenticatedRequest, res: Response) => {
      try {
        const myPhone = req.authUser!.phoneNormalized;

        // Mark any 'sent' messages addressed to me as 'delivered' and notify online senders
        const deliveredReceipts = await markUndeliveredMessagesDelivered(myPhone);
        for (const receipt of deliveredReceipts) {
          realtimeHub.sendToPhone(receipt.senderPhone, {
            type: 'message:status',
            peerPhone: myPhone,
            messageIds: receipt.messageIds,
            status: 'delivered',
          });
        }

        const { messages, peers } = await fetchUserDirectMessagesAndPeers(myPhone);
        const enrichedPeers = peers.map((p) => {
          const presence = realtimeHub.getPresence(p.phoneNormalized);
          return {
            ...p,
            online: presence.online,
            lastSeen: presence.lastSeen,
          };
        });

        res.json({
          messages,
          peers: enrichedPeers,
        });
      } catch (error) {
        console.error('Error in GET /api/messages/inbox:', error);
        res.status(500).json({
          code: 'INBOX_FETCH_FAILED',
          error: 'Failed to load real messages.',
        });
      }
    }
  );

  // 15. Send a Real Message to Another ZOLO Mobile Number
  app.post(
    '/api/messages/send',
    requireSessionAuth,
    async (req: AuthenticatedRequest, res: Response) => {
      try {
        const sender = req.authUser!;
        const {
          messageId,
          recipientPhone,
          countryIso = 'IN',
          dialCode = '+91',
          text = '',
          mediaType = 'text',
          payload = {},
        } = req.body as {
          messageId?: string;
          recipientPhone?: string;
          countryIso?: string;
          dialCode?: string;
          text?: string;
          mediaType?: DirectMessageDto['mediaType'];
          payload?: MessageRichPayload;
        };

        const normRecipient = normalizeAndValidatePhone(
          recipientPhone || '',
          (countryIso || 'IN') as CountryCode,
          dialCode
        );
        if (!normRecipient.valid || !normRecipient.e164) {
          res.status(400).json({
            code: 'INVALID_RECIPIENT_PHONE',
            error: normRecipient.error || 'Recipient mobile number is invalid.',
          });
          return;
        }

        const safeMessageId =
          typeof messageId === 'string' && messageId.trim().length > 4
            ? messageId.trim()
            : `dm_${Date.now()}_${crypto.randomBytes(6).toString('hex')}`;

        const targetPhone = normRecipient.e164;
        const isSelf = targetPhone === sender.phoneNormalized;
        const isRecipientOnline = !isSelf && realtimeHub.isPhoneOnline(targetPhone);

        const initialStatus: DirectMessageDto['status'] = isSelf
          ? 'read'
          : isRecipientOnline
          ? 'delivered'
          : 'sent';

        const savedMessage = await saveDirectMessage({
          messageId: safeMessageId,
          senderPhone: sender.phoneNormalized,
          senderName: sender.fullName,
          senderAvatar: sender.avatarUrl ?? null,
          recipientPhone: targetPhone,
          text: String(text || ''),
          mediaType,
          payload: payload || {},
          initialStatus,
        });

        const senderProfile = {
          uid: sender.uid,
          phoneNormalized: sender.phoneNormalized,
          fullName: sender.fullName,
          about: sender.about,
          avatarUrl: sender.avatarUrl ?? null,
        };

        // Push to recipient's connected devices immediately
        if (!isSelf) {
          realtimeHub.sendToPhone(targetPhone, {
            type: 'message:new',
            message: savedMessage,
            senderProfile,
          });
        }

        // Also sync to sender's other active tabs/devices
        realtimeHub.sendToPhone(sender.phoneNormalized, {
          type: 'message:new',
          message: savedMessage,
          senderProfile,
        });

        const recipientProfiles = await lookupRegisteredUsersByPhones([targetPhone]);
        const recipientProfile = recipientProfiles[0] || null;
        const presence = realtimeHub.getPresence(targetPhone);

        res.status(201).json({
          message: savedMessage,
          recipientRegistered: Boolean(recipientProfile),
          recipientProfile: recipientProfile
            ? {
                ...recipientProfile,
                online: presence.online,
                lastSeen: presence.lastSeen,
              }
            : null,
        });
      } catch (error) {
        console.error('Error in POST /api/messages/send:', error);
        res.status(500).json({
          code: 'MESSAGE_SEND_FAILED',
          error: 'Failed to send message. Please try again.',
        });
      }
    }
  );

  // 16. Mark Incoming Messages from Peer as Read (Triggers Blue Ticks for Sender)
  app.post(
    '/api/messages/read',
    requireSessionAuth,
    async (req: AuthenticatedRequest, res: Response) => {
      try {
        const myPhone = req.authUser!.phoneNormalized;
        const { peerPhone } = req.body as { peerPhone?: string };
        const normPeer = normalizeAndValidatePhone(peerPhone || '', 'IN', '+91');
        if (!normPeer.valid || !normPeer.e164) {
          res.status(400).json({ code: 'INVALID_PHONE', error: 'Invalid peer phone number.' });
          return;
        }

        const updatedIds = await markConversationReadInDb(myPhone, normPeer.e164);
        if (updatedIds.length > 0) {
          realtimeHub.sendToPhone(normPeer.e164, {
            type: 'message:status',
            peerPhone: myPhone,
            messageIds: updatedIds,
            status: 'read',
          });
        }

        res.json({ updatedCount: updatedIds.length, messageIds: updatedIds });
      } catch (error) {
        console.error('Error in POST /api/messages/read:', error);
        res.status(500).json({ code: 'READ_RECEIPT_FAILED', error: 'Failed to mark read.' });
      }
    }
  );

  // 17. Toggle Reaction on a Real Direct Message
  app.patch(
    '/api/messages/:messageId/react',
    requireSessionAuth,
    async (req: AuthenticatedRequest, res: Response) => {
      try {
        const actor = req.authUser!;
        const messageId = String(req.params.messageId || '').trim();
        const { emoji } = req.body as { emoji?: string };
        if (!messageId || !emoji) {
          res.status(400).json({ code: 'INVALID_REACTION', error: 'Emoji is required.' });
          return;
        }

        const updated = await toggleMessageReactionInDb({
          messageId,
          actorPhone: actor.phoneNormalized,
          actorName: actor.fullName,
          emoji: String(emoji).slice(0, 8),
        });

        if (!updated) {
          res.status(404).json({ code: 'MESSAGE_NOT_FOUND', error: 'Message not found.' });
          return;
        }

        realtimeHub.sendToPhone(updated.senderPhone, {
          type: 'message:updated',
          message: updated,
        });
        if (updated.recipientPhone !== updated.senderPhone) {
          realtimeHub.sendToPhone(updated.recipientPhone, {
            type: 'message:updated',
            message: updated,
          });
        }

        res.json({ message: updated });
      } catch (error) {
        console.error('Error in PATCH /api/messages/:messageId/react:', error);
        res.status(500).json({ code: 'REACTION_FAILED', error: 'Failed to update reaction.' });
      }
    }
  );

  // 18. Vote on a Poll in a Real Direct Message
  app.patch(
    '/api/messages/:messageId/poll-vote',
    requireSessionAuth,
    async (req: AuthenticatedRequest, res: Response) => {
      try {
        const actor = req.authUser!;
        const messageId = String(req.params.messageId || '').trim();
        const { optionId } = req.body as { optionId?: string };
        if (!messageId || !optionId) {
          res.status(400).json({ code: 'INVALID_VOTE', error: 'Poll option ID is required.' });
          return;
        }

        const updated = await voteMessagePollInDb({
          messageId,
          actorPhone: actor.phoneNormalized,
          voterName: actor.fullName,
          optionId: String(optionId),
        });

        if (!updated) {
          res.status(404).json({ code: 'MESSAGE_NOT_FOUND', error: 'Poll message not found.' });
          return;
        }

        realtimeHub.sendToPhone(updated.senderPhone, {
          type: 'message:updated',
          message: updated,
        });
        if (updated.recipientPhone !== updated.senderPhone) {
          realtimeHub.sendToPhone(updated.recipientPhone, {
            type: 'message:updated',
            message: updated,
          });
        }

        res.json({ message: updated });
      } catch (error) {
        console.error('Error in PATCH /api/messages/:messageId/poll-vote:', error);
        res.status(500).json({ code: 'POLL_VOTE_FAILED', error: 'Failed to record poll vote.' });
      }
    }
  );

  // 19. Delete a Real Direct Message
  app.delete(
    '/api/messages/:messageId',
    requireSessionAuth,
    async (req: AuthenticatedRequest, res: Response) => {
      try {
        const actor = req.authUser!;
        const messageId = String(req.params.messageId || '').trim();
        if (!messageId) {
          res.status(400).json({ code: 'INVALID_ID', error: 'Message ID is required.' });
          return;
        }

        const deleted = await deleteDirectMessageInDb(messageId, actor.phoneNormalized);
        if (!deleted) {
          res.status(404).json({ code: 'MESSAGE_NOT_FOUND', error: 'Message not found.' });
          return;
        }

        realtimeHub.sendToPhone(deleted.senderPhone, {
          type: 'message:deleted',
          ...deleted,
        });
        if (deleted.recipientPhone !== deleted.senderPhone) {
          realtimeHub.sendToPhone(deleted.recipientPhone, {
            type: 'message:deleted',
            ...deleted,
          });
        }

        res.json({ deleted: true });
      } catch (error) {
        console.error('Error in DELETE /api/messages/:messageId:', error);
        res.status(500).json({ code: 'DELETE_FAILED', error: 'Failed to delete message.' });
      }
    }
  );

  // =========================================================================
  // SHARED 24-HOUR STATUS STORIES & REAL INTERNET CALL LOGS ENDPOINTS
  // =========================================================================

  // 19b. Change Account Password
  app.post(
    '/api/account/password',
    requireSessionAuth,
    async (req: AuthenticatedRequest, res: Response) => {
      try {
        const { currentPassword, newPassword } = req.body as {
          currentPassword?: string;
          newPassword?: string;
        };
        if (!newPassword || newPassword.length < 6 || newPassword.length > 128) {
          res.status(400).json({
            code: 'INVALID_PASSWORD',
            error: 'New password must be at least 6 characters long.',
          });
          return;
        }
        const updated = await changeAccountPassword({
          userId: req.authUser!.id,
          currentPassword,
          newPassword,
        });
        res.json({ user: toPublicUser(updated) });
      } catch (error: unknown) {
        if (error instanceof AppDomainError) {
          res.status(error.statusCode).json({ code: error.code, error: error.message });
          return;
        }
        res.status(500).json({ code: 'PASSWORD_UPDATE_FAILED', error: 'Failed to update password.' });
      }
    }
  );

  // 19c. Fetch Visible 24h Status Stories from Contacts in User's Chats
  app.post(
    '/api/statuses/feed',
    requireSessionAuth,
    async (req: AuthenticatedRequest, res: Response) => {
      try {
        const myPhone = req.authUser!.phoneNormalized;
        const { contactPhones = [] } = req.body as { contactPhones?: string[] };

        const normalizedList: string[] = [];
        if (Array.isArray(contactPhones)) {
          for (const raw of contactPhones) {
            const norm = normalizeAndValidatePhone(String(raw || ''), 'IN', '+91');
            if (norm.valid && norm.e164) {
              normalizedList.push(norm.e164);
            }
          }
        }

        const stories = await fetchVisibleStatusStories({
          viewerPhone: myPhone,
          contactPhones: normalizedList,
        });

        res.json({ stories });
      } catch (error) {
        console.error('Error in POST /api/statuses/feed:', error);
        res.status(500).json({ code: 'STATUS_FEED_FAILED', error: 'Failed to load statuses.' });
      }
    }
  );

  // 19d. Publish a New Status Story (Broadcasts Live to Connected Users Who Have Author in Chats)
  app.post(
    '/api/statuses',
    requireSessionAuth,
    async (req: AuthenticatedRequest, res: Response) => {
      try {
        const author = req.authUser!;
        const {
          storyId,
          storyType = 'text',
          textContent,
          mediaUrl,
          caption,
          bgColor,
        } = req.body as {
          storyId?: string;
          storyType?: 'text' | 'image';
          textContent?: string;
          mediaUrl?: string;
          caption?: string;
          bgColor?: string;
        };

        const type = storyType === 'image' ? 'image' : 'text';
        if (type === 'text' && (!textContent || !textContent.trim())) {
          res.status(400).json({ code: 'EMPTY_STATUS', error: 'Status text cannot be empty.' });
          return;
        }
        if (type === 'image' && (!mediaUrl || !mediaUrl.trim())) {
          res.status(400).json({ code: 'EMPTY_STATUS_IMAGE', error: 'Status image is required.' });
          return;
        }

        const safeStoryId =
          typeof storyId === 'string' && storyId.trim().length > 4
            ? storyId.trim()
            : `st_${Date.now()}_${crypto.randomBytes(5).toString('hex')}`;

        const created = await createStatusStoryInDb({
          storyId: safeStoryId,
          authorPhone: author.phoneNormalized,
          authorName: author.fullName,
          authorAvatar: author.avatarUrl ?? null,
          storyType: type,
          textContent: type === 'text' ? String(textContent || '').trim() : null,
          mediaUrl: type === 'image' ? String(mediaUrl || '').trim() : null,
          caption: type === 'image' && caption ? String(caption).trim() : null,
          bgColor: type === 'text' ? String(bgColor || '#005c4b') : null,
        });

        // Broadcast to connected clients; each client filters to stories from contacts in their chats
        realtimeHub.broadcastAll({
          type: 'status:new',
          story: created,
        });

        res.status(201).json({ story: created });
      } catch (error) {
        console.error('Error in POST /api/statuses:', error);
        res.status(500).json({ code: 'STATUS_CREATE_FAILED', error: 'Failed to publish status.' });
      }
    }
  );

  // 19e. Mark Status Story Viewed
  app.post(
    '/api/statuses/:storyId/view',
    requireSessionAuth,
    async (req: AuthenticatedRequest, res: Response) => {
      try {
        const viewerPhone = req.authUser!.phoneNormalized;
        const storyId = String(req.params.storyId || '').trim();
        if (!storyId) {
          res.status(400).json({ code: 'INVALID_STORY_ID', error: 'Story ID required.' });
          return;
        }

        const updated = await markStatusStoryViewedInDb(storyId, viewerPhone);
        if (updated && updated.authorPhone !== viewerPhone) {
          realtimeHub.sendToPhone(updated.authorPhone, {
            type: 'status:viewed',
            story: updated,
          });
        }

        res.json({ story: updated });
      } catch (error) {
        console.error('Error in POST /api/statuses/:storyId/view:', error);
        res.status(500).json({ code: 'STATUS_VIEW_FAILED', error: 'Failed to mark status viewed.' });
      }
    }
  );

  // 19f. Fetch User's Real Call Logs (Audio, Video & Missed Calls)
  app.get(
    '/api/calls/history',
    requireSessionAuth,
    async (req: AuthenticatedRequest, res: Response) => {
      try {
        const myPhone = req.authUser!.phoneNormalized;
        const calls = await fetchUserCallHistory(myPhone);
        res.json({ calls });
      } catch (error) {
        console.error('Error in GET /api/calls/history:', error);
        res.status(500).json({ code: 'CALL_HISTORY_FAILED', error: 'Failed to load call logs.' });
      }
    }
  );

  // 19g. Mark Unseen Missed Calls as Seen When Opening Calls Tab
  app.post(
    '/api/calls/mark-missed-seen',
    requireSessionAuth,
    async (req: AuthenticatedRequest, res: Response) => {
      try {
        const updatedCount = await markMissedCallsSeenInDb(req.authUser!.phoneNormalized);
        res.json({ updatedCount });
      } catch {
        res.status(500).json({ code: 'MARK_SEEN_FAILED', error: 'Failed to clear missed calls badge.' });
      }
    }
  );

  // 20. List Active Sessions
  app.get(
    '/api/account/sessions',
    requireSessionAuth,
    async (req: AuthenticatedRequest, res: Response) => {
      try {
        const sessions = await listActiveSessionsForUser(
          req.authUser!.id,
          req.authSession!.sessionId
        );
        res.json({ sessions });
      } catch {
        res.status(500).json({
          code: 'SESSIONS_FETCH_FAILED',
          error: 'Failed to load active sessions.',
        });
      }
    }
  );

  // 21. Logout Current Device
  app.post(
    '/api/auth/logout',
    requireSessionAuth,
    async (req: AuthenticatedRequest, res: Response) => {
      try {
        await revokeSingleSession(req.authSession!.sessionId, req.authUser!.id);
        clearSessionCookie(req, res);
        res.json({ loggedOut: true });
      } catch {
        res.status(500).json({ code: 'LOGOUT_FAILED', error: 'Failed to sign out.' });
      }
    }
  );

  // 22. Logout All Devices
  app.post(
    '/api/auth/logout-all',
    requireSessionAuth,
    async (req: AuthenticatedRequest, res: Response) => {
      try {
        const revokedCount = await revokeAllSessionsForUser(req.authUser!.id);
        clearSessionCookie(req, res);
        res.json({ loggedOut: true, revokedCount });
      } catch {
        res.status(500).json({
          code: 'LOGOUT_ALL_FAILED',
          error: 'Failed to sign out of all devices.',
        });
      }
    }
  );

  // 23. Delete Lifetime Account Permanently
  app.delete(
    '/api/account',
    requireSessionAuth,
    async (req: AuthenticatedRequest, res: Response) => {
      try {
        const { confirmPhrase } = req.body as { confirmPhrase?: string };
        if (confirmPhrase !== 'DELETE') {
          res.status(400).json({
            code: 'CONFIRMATION_REQUIRED',
            error: 'Type DELETE to confirm permanent account removal.',
          });
          return;
        }
        await permanentlyDeleteAccount(req.authUser!.id);
        clearSessionCookie(req, res);
        res.json({ deleted: true });
      } catch {
        res.status(500).json({
          code: 'DELETE_ACCOUNT_FAILED',
          error: 'Failed to delete account.',
        });
      }
    }
  );

  return app;
}
