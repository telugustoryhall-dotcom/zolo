import React, { useState, useEffect } from 'react';
import { Contact, Message, StatusStory, CallLog, UserProfile, LocationData, PollData } from './types/chat';
import {
  INITIAL_USER,
  INITIAL_CONTACTS,
  INITIAL_MESSAGES,
  INITIAL_STATUSES,
  INITIAL_CALLS,
} from './data/initialData';
import { Sidebar } from './components/Sidebar';
import { ChatArea } from './components/ChatArea';
import { CallModal } from './components/CallModal';
import { StatusViewerModal } from './components/StatusViewerModal';
import { StatusCreatorModal } from './components/StatusCreatorModal';
import { NewChatModal } from './components/NewChatModal';
import { NewGroupModal } from './components/NewGroupModal';
import { ContactInfoDrawer } from './components/ContactInfoDrawer';
import {
  ImagePreviewModal,
  LocationPickerModal,
  CreatePollModal,
} from './components/AttachmentModals';
import { sound } from './utils/audio';
import { getSimulatedReply } from './utils/botReplies';
import { MessageSquare, Shield, Lock, Laptop } from 'lucide-react';

const STORAGE_KEY = 'skaarchat_state_v1';

export default function App() {
  // Load saved state or use initial mock data
  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_user`);
      return saved ? JSON.parse(saved) : INITIAL_USER;
    } catch {
      return INITIAL_USER;
    }
  });

  const [contacts, setContacts] = useState<Contact[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_contacts`);
      return saved ? JSON.parse(saved) : INITIAL_CONTACTS;
    } catch {
      return INITIAL_CONTACTS;
    }
  });

  const [messages, setMessages] = useState<Record<string, Message[]>>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_messages`);
      return saved ? JSON.parse(saved) : INITIAL_MESSAGES;
    } catch {
      return INITIAL_MESSAGES;
    }
  });

  const [statuses, setStatuses] = useState<StatusStory[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_statuses`);
      return saved ? JSON.parse(saved) : INITIAL_STATUSES;
    } catch {
      return INITIAL_STATUSES;
    }
  });

  const [callLogs, setCallLogs] = useState<CallLog[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_calls`);
      return saved ? JSON.parse(saved) : INITIAL_CALLS;
    } catch {
      return INITIAL_CALLS;
    }
  });

  // Active chat state
  const [activeContactId, setActiveContactId] = useState<string | null>('c1');
  const [typingContactId, setTypingContactId] = useState<string | null>(null);

  // Modals & Panels state
  const [activeCall, setActiveCall] = useState<{
    contact: Contact;
    type: 'audio' | 'video';
    isIncoming?: boolean;
  } | null>(null);

  const [statusViewerIndex, setStatusViewerIndex] = useState<number | null>(null);
  const [isStatusCreatorOpen, setIsStatusCreatorOpen] = useState(false);
  const [isNewChatOpen, setIsNewChatOpen] = useState(false);
  const [isNewGroupOpen, setIsNewGroupOpen] = useState(false);
  const [isContactInfoOpen, setIsContactInfoOpen] = useState(false);
  const [previewImageModalUrl, setPreviewImageModalUrl] = useState<string | null>(null);
  const [isPollModalOpen, setIsPollModalOpen] = useState(false);
  const [isLocationModalOpen, setIsLocationModalOpen] = useState(false);

  // Sync state to LocalStorage
  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_user`, JSON.stringify(userProfile));
  }, [userProfile]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_contacts`, JSON.stringify(contacts));
  }, [contacts]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_messages`, JSON.stringify(messages));
  }, [messages]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_statuses`, JSON.stringify(statuses));
  }, [statuses]);

  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY}_calls`, JSON.stringify(callLogs));
  }, [callLogs]);

  // Apply dark / light class to root
  useEffect(() => {
    if (userProfile.theme === 'dark') {
      document.documentElement.classList.add('dark');
      document.body.style.backgroundColor = '#111b21';
    } else {
      document.documentElement.classList.remove('dark');
      document.body.style.backgroundColor = '#f0f2f5';
    }
  }, [userProfile.theme]);

  const activeContact = contacts.find((c) => c.id === activeContactId) || null;
  const activeMessages = activeContactId ? messages[activeContactId] || [] : [];

  // Reset to initial demo data
  const handleResetData = () => {
    setUserProfile(INITIAL_USER);
    setContacts(INITIAL_CONTACTS);
    setMessages(INITIAL_MESSAGES);
    setStatuses(INITIAL_STATUSES);
    setCallLogs(INITIAL_CALLS);
    setActiveContactId('c1');
    localStorage.clear();
  };

  // Toggle Theme
  const handleToggleTheme = () => {
    setUserProfile((prev) => ({
      ...prev,
      theme: prev.theme === 'dark' ? 'light' : 'dark',
    }));
  };

  // Select contact & clear unread badge
  const handleSelectContact = (id: string) => {
    setActiveContactId(id);
    setContacts((prev) =>
      prev.map((c) => (c.id === id ? { ...c, unreadCount: 0 } : c))
    );
  };

  // Send message handler
  const handleSendMessage = (
    text: string,
    mediaType: Message['mediaType'] = 'text',
    extraData: Partial<Message> = {}
  ) => {
    if (!activeContactId || !activeContact) return;

    if (userProfile.soundEnabled) {
      sound.playSendSound();
    }

    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const newMessage: Message = {
      id: `msg_${Date.now()}`,
      chatId: activeContactId,
      senderId: 'user',
      senderName: userProfile.name,
      text,
      timestamp: timeStr,
      timestampRaw: Date.now(),
      status: 'sent',
      mediaType,
      ...extraData,
    };

    // Update messages
    setMessages((prev) => ({
      ...prev,
      [activeContactId]: [...(prev[activeContactId] || []), newMessage],
    }));

    // Mark sent -> delivered quickly
    setTimeout(() => {
      setMessages((prev) => ({
        ...prev,
        [activeContactId]: (prev[activeContactId] || []).map((m) =>
          m.id === newMessage.id ? { ...m, status: 'delivered' } : m
        ),
      }));
    }, 800);

    // Simulate contact reply after a brief typing indicator
    if (!activeContact.isGroup) {
      setTimeout(() => {
        setTypingContactId(activeContactId);
      }, 1400);

      setTimeout(() => {
        setTypingContactId(null);

        // Mark user's message as read (blue tick)
        setMessages((prev) => ({
          ...prev,
          [activeContactId]: (prev[activeContactId] || []).map((m) =>
            m.id === newMessage.id ? { ...m, status: 'read' } : m
          ),
        }));

        const replyText = getSimulatedReply(activeContact, text);
        const replyNow = new Date();
        const replyTime = replyNow.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

        const incomingMsg: Message = {
          id: `msg_bot_${Date.now()}`,
          chatId: activeContactId,
          senderId: activeContact.id,
          senderName: activeContact.name,
          text: replyText,
          timestamp: replyTime,
          timestampRaw: Date.now(),
          status: 'read',
          mediaType: 'text',
        };

        setMessages((prev) => ({
          ...prev,
          [activeContactId]: [...(prev[activeContactId] || []), incomingMsg],
        }));

        if (userProfile.soundEnabled) {
          sound.playReceiveSound();
        }
      }, 3200);
    }
  };

  // Reactions
  const handleReactMessage = (messageId: string, emoji: string) => {
    if (!activeContactId) return;
    setMessages((prev) => {
      const chatMsgs = prev[activeContactId] || [];
      const updated = chatMsgs.map((m) => {
        if (m.id !== messageId) return m;
        const currentReactions = m.reactions || [];
        const existing = currentReactions.find((r) => r.emoji === emoji);

        let newReactions;
        if (existing) {
          // Toggle off if already reacted
          newReactions = currentReactions.filter((r) => r.emoji !== emoji);
        } else {
          newReactions = [...currentReactions, { emoji, count: 1, users: ['You'] }];
        }
        return { ...m, reactions: newReactions };
      });
      return { ...prev, [activeContactId]: updated };
    });
  };

  // Star message
  const handleStarMessage = (messageId: string) => {
    if (!activeContactId) return;
    setMessages((prev) => {
      const chatMsgs = prev[activeContactId] || [];
      const updated = chatMsgs.map((m) =>
        m.id === messageId ? { ...m, isStarred: !m.isStarred } : m
      );
      return { ...prev, [activeContactId]: updated };
    });
  };

  // Delete message
  const handleDeleteMessage = (messageId: string, forEveryone: boolean) => {
    if (!activeContactId) return;
    setMessages((prev) => {
      const chatMsgs = prev[activeContactId] || [];
      const updated = chatMsgs.filter((m) => m.id !== messageId);
      return { ...prev, [activeContactId]: updated };
    });
  };

  // Vote on Poll
  const handleVotePoll = (messageId: string, optionId: string) => {
    if (!activeContactId) return;
    setMessages((prev) => {
      const chatMsgs = prev[activeContactId] || [];
      const updated = chatMsgs.map((m) => {
        if (m.id !== messageId || !m.poll) return m;
        const currentPoll = m.poll;
        const prevVoteId = currentPoll.userVotedId;

        const updatedOptions = currentPoll.options.map((opt) => {
          if (opt.id === optionId) {
            // If already voted for this option, unvote
            if (prevVoteId === optionId) {
              return {
                ...opt,
                votes: Math.max(0, opt.votes - 1),
                voterNames: opt.voterNames.filter((n) => n !== 'You'),
              };
            }
            return {
              ...opt,
              votes: opt.votes + 1,
              voterNames: [...opt.voterNames, 'You'],
            };
          }
          if (opt.id === prevVoteId && !currentPoll.allowMultipleAnswers) {
            // Remove previous vote if single-vote poll
            return {
              ...opt,
              votes: Math.max(0, opt.votes - 1),
              voterNames: opt.voterNames.filter((n) => n !== 'You'),
            };
          }
          return opt;
        });

        return {
          ...m,
          poll: {
            ...currentPoll,
            userVotedId: prevVoteId === optionId ? undefined : optionId,
            options: updatedOptions,
          },
        };
      });
      return { ...prev, [activeContactId]: updated };
    });
  };

  // Status Story Reply
  const handleReplyStatus = (contactId: string, replyText: string, statusInfo: StatusStory) => {
    handleSelectContact(contactId);
    handleSendMessage(`Replying to status "${statusInfo.caption || statusInfo.text || 'Photo'}": ${replyText}`);
  };

  // Start Call
  const handleStartCall = (contactId: string, type: 'audio' | 'video') => {
    const contact = contacts.find((c) => c.id === contactId);
    if (!contact) return;
    setActiveCall({ contact, type, isIncoming: false });
  };

  // Close Call and add to call logs
  const handleCloseCall = (durationStr?: string) => {
    if (activeCall) {
      const newLog: CallLog = {
        id: `call_${Date.now()}`,
        contactId: activeCall.contact.id,
        contactName: activeCall.contact.name,
        contactAvatar: activeCall.contact.avatar,
        type: activeCall.type,
        direction: 'outgoing',
        timestamp: 'Just now',
        duration: durationStr || '14s',
      };
      setCallLogs((prev) => [newLog, ...prev]);
    }
    setActiveCall(null);
  };

  // Pin, Mute, Archive toggles
  const handleTogglePin = (contactId: string) => {
    setContacts((prev) =>
      prev.map((c) => (c.id === contactId ? { ...c, isPinned: !c.isPinned } : c))
    );
  };

  const handleToggleMute = (contactId: string) => {
    setContacts((prev) =>
      prev.map((c) => (c.id === contactId ? { ...c, isMuted: !c.isMuted } : c))
    );
  };

  const handleToggleArchive = (contactId: string) => {
    setContacts((prev) =>
      prev.map((c) => (c.id === contactId ? { ...c, isArchived: !c.isArchived } : c))
    );
  };

  const isDark = userProfile.theme === 'dark';

  return (
    <div
      className={`h-screen w-screen overflow-hidden flex flex-col font-sans select-none ${
        isDark ? 'bg-[#0c1317] text-white' : 'bg-[#e2e5e9] text-slate-900'
      }`}
    >
      {/* WhatsApp Web Desktop Header Bar */}
      <div className="hidden lg:block w-full h-8 bg-[#00a884] shrink-0" />

      {/* Main Container Wrapper */}
      <div className="flex-1 flex justify-center items-center overflow-hidden lg:p-4 lg:pt-0">
        <div
          className={`w-full h-full lg:max-w-[1600px] lg:h-[calc(100vh-2rem)] flex overflow-hidden shadow-2xl transition-all duration-200 lg:rounded-2xl border ${
            isDark ? 'bg-[#111b21] border-slate-800' : 'bg-white border-slate-300'
          }`}
        >
          {/* Sidebar Area */}
          <div
            className={`h-full ${
              activeContactId ? 'hidden md:flex' : 'flex w-full'
            }`}
          >
            <Sidebar
              contacts={contacts}
              activeContactId={activeContactId}
              statuses={statuses}
              callLogs={callLogs}
              allMessages={messages}
              currentUser={userProfile}
              theme={userProfile.theme}
              typingContactId={typingContactId}
              onSelectContact={handleSelectContact}
              onOpenNewChat={() => setIsNewChatOpen(true)}
              onOpenNewGroup={() => setIsNewGroupOpen(true)}
              onOpenStatusViewer={(index) => setStatusViewerIndex(index)}
              onOpenStatusCreator={() => setIsStatusCreatorOpen(true)}
              onStartCall={handleStartCall}
              onTogglePin={handleTogglePin}
              onToggleMute={handleToggleMute}
              onToggleArchive={handleToggleArchive}
              onToggleTheme={handleToggleTheme}
              onUpdateProfile={(updated) => setUserProfile((p) => ({ ...p, ...updated }))}
              onResetData={handleResetData}
            />
          </div>

          {/* Active Chat Conversation Area */}
          {activeContact ? (
            <div
              className={`flex-1 h-full flex overflow-hidden ${
                !activeContactId ? 'hidden md:flex' : 'flex'
              }`}
            >
              <ChatArea
                contact={activeContact}
                messages={activeMessages}
                currentUser={userProfile}
                theme={userProfile.theme}
                isTyping={typingContactId === activeContact.id}
                onSendMessage={handleSendMessage}
                onAudioCall={() => handleStartCall(activeContact.id, 'audio')}
                onVideoCall={() => handleStartCall(activeContact.id, 'video')}
                onToggleContactInfo={() => setIsContactInfoOpen(!isContactInfoOpen)}
                onReactMessage={handleReactMessage}
                onStarMessage={handleStarMessage}
                onDeleteMessage={handleDeleteMessage}
                onVotePoll={handleVotePoll}
                onOpenImageModal={(url) => setPreviewImageModalUrl(url)}
                onOpenPollModal={() => setIsPollModalOpen(true)}
                onOpenLocationModal={() => setIsLocationModalOpen(true)}
                onBackMobile={() => setActiveContactId(null)}
              />

              {/* Right Side Contact Info Drawer */}
              {isContactInfoOpen && (
                <ContactInfoDrawer
                  contact={activeContact}
                  messages={activeMessages}
                  theme={userProfile.theme}
                  onClose={() => setIsContactInfoOpen(false)}
                  onAudioCall={() => handleStartCall(activeContact.id, 'audio')}
                  onVideoCall={() => handleStartCall(activeContact.id, 'video')}
                  onToggleMute={() => handleToggleMute(activeContact.id)}
                  onUpdateAvatar={(contactId, newAvatar) => {
                    setContacts((prev) =>
                      prev.map((c) => (c.id === contactId ? { ...c, avatar: newAvatar } : c))
                    );
                    const target = contacts.find((c) => c.id === contactId);
                    if (target?.isGroup) {
                      const now = new Date();
                      const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                      setMessages((prev) => ({
                        ...prev,
                        [contactId]: [
                          ...(prev[contactId] || []),
                          {
                            id: `msg_sys_${Date.now()}`,
                            chatId: contactId,
                            senderId: 'system',
                            senderName: 'SkaarChat',
                            text: newAvatar ? 'You changed the group icon' : 'You removed the group icon',
                            timestamp: timeStr,
                            timestampRaw: Date.now(),
                            status: 'read',
                            mediaType: 'text',
                          },
                        ],
                      }));
                    }
                  }}
                  onUpdateDisappearing={(setting) => {
                    setContacts((prev) =>
                      prev.map((c) =>
                        c.id === activeContact.id ? { ...c, disappearingMessages: setting } : c
                      )
                    );
                  }}
                />
              )}
            </div>
          ) : (
            /* Welcome / Empty Screen when no chat selected */
            <div
              className={`hidden md:flex flex-1 flex-col items-center justify-center p-8 text-center border-l ${
                isDark ? 'bg-[#222e35] border-slate-800 text-slate-300' : 'bg-[#f0f2f5] border-slate-200 text-slate-600'
              }`}
            >
              <div className="w-24 h-24 rounded-full bg-emerald-600/20 text-[#00a884] flex items-center justify-center mb-6 shadow-inner">
                <Laptop className="w-12 h-12 stroke-[1.5]" />
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight mb-3">
                SkaarChat for Web
              </h2>
              <p className="max-w-md text-sm text-slate-400 leading-relaxed mb-8">
                Send and receive messages with your contacts, create interactive polls, record voice notes with waveforms, make audio and video calls, and share stories.
              </p>
              <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
                <Lock className="w-3.5 h-3.5" />
                <span>End-to-end encrypted</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 3. MODALS */}

      {/* Call Modal */}
      {activeCall && (
        <CallModal
          contact={activeCall.contact}
          type={activeCall.type}
          isIncoming={activeCall.isIncoming}
          onClose={handleCloseCall}
        />
      )}

      {/* Status Viewer Modal */}
      {statusViewerIndex !== null && (
        <StatusViewerModal
          statuses={statuses}
          initialIndex={statusViewerIndex}
          onClose={() => setStatusViewerIndex(null)}
          onReply={handleReplyStatus}
        />
      )}

      {/* Status Creator Modal */}
      {isStatusCreatorOpen && (
        <StatusCreatorModal
          onClose={() => setIsStatusCreatorOpen(false)}
          onAddStatus={(newStatus) => {
            setStatuses((prev) => [newStatus, ...prev]);
          }}
        />
      )}

      {/* New Chat Modal */}
      {isNewChatOpen && (
        <NewChatModal
          contacts={contacts}
          theme={userProfile.theme}
          onClose={() => setIsNewChatOpen(false)}
          onSelectContact={handleSelectContact}
          onOpenNewGroup={() => setIsNewGroupOpen(true)}
          onAddNewContact={(name, phone, about) => {
            const newContact: Contact = {
              id: `c_${Date.now()}`,
              name,
              phone,
              avatar: '',
              about,
              online: true,
              lastSeen: 'online',
              unreadCount: 0,
            };
            setContacts((prev) => [newContact, ...prev]);
            handleSelectContact(newContact.id);
          }}
        />
      )}

      {/* New Group Modal */}
      {isNewGroupOpen && (
        <NewGroupModal
          contacts={contacts}
          theme={userProfile.theme}
          onClose={() => setIsNewGroupOpen(false)}
          onCreateGroup={(groupName, selectedContactIds, groupAvatar) => {
            const newGroup: Contact = {
              id: `group_${Date.now()}`,
              name: groupName,
              phone: `Group (${selectedContactIds.length + 1} members)`,
              avatar: groupAvatar || '',
              about: 'Group chat created on SkaarChat',
              online: false,
              lastSeen: 'Group Members',
              isGroup: true,
              groupMembers: selectedContactIds,
              unreadCount: 0,
            };
            setContacts((prev) => [newGroup, ...prev]);
            setMessages((prev) => ({
              ...prev,
              [newGroup.id]: [
                {
                  id: `msg_sys_${Date.now()}`,
                  chatId: newGroup.id,
                  senderId: 'system',
                  senderName: 'SkaarChat',
                  text: `You created group "${groupName}"`,
                  timestamp: 'Just now',
                  timestampRaw: Date.now(),
                  status: 'read',
                  mediaType: 'text',
                },
              ],
            }));
            handleSelectContact(newGroup.id);
          }}
        />
      )}

      {/* Image Modal Viewer */}
      {previewImageModalUrl && (
        <div
          onClick={() => setPreviewImageModalUrl(null)}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4 cursor-zoom-out"
        >
          <img
            src={previewImageModalUrl}
            alt="Enlarged"
            className="max-h-[90vh] max-w-[90vw] object-contain rounded-xl shadow-2xl"
          />
        </div>
      )}

      {/* Create Poll Modal */}
      {isPollModalOpen && (
        <CreatePollModal
          theme={userProfile.theme}
          onClose={() => setIsPollModalOpen(false)}
          onSendPoll={(poll) => {
            handleSendMessage(poll.question, 'poll', { poll });
          }}
        />
      )}

      {/* Share Location Modal */}
      {isLocationModalOpen && (
        <LocationPickerModal
          theme={userProfile.theme}
          onClose={() => setIsLocationModalOpen(false)}
          onSendLocation={(loc) => {
            handleSendMessage(`Location: ${loc.name}`, 'location', { location: loc });
          }}
        />
      )}
    </div>
  );
}
