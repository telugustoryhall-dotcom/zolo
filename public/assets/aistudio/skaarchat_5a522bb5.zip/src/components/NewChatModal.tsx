import React, { useState } from 'react';
import { Contact } from '../types/chat';
import { X, Search, UserPlus, Users, MessageSquare } from 'lucide-react';

interface NewChatModalProps {
  contacts: Contact[];
  theme: 'dark' | 'light';
  onClose: () => void;
  onSelectContact: (contactId: string) => void;
  onOpenNewGroup: () => void;
  onAddNewContact: (name: string, phone: string, about: string) => void;
}

export const NewChatModal: React.FC<NewChatModalProps> = ({
  contacts,
  theme,
  onClose,
  onSelectContact,
  onOpenNewGroup,
  onAddNewContact,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isAddingCustom, setIsAddingCustom] = useState(false);
  const [newName, setNewName] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newAbout, setNewAbout] = useState('Hey there! I am using SkaarChat.');

  const filteredContacts = contacts.filter((c) =>
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.phone.includes(searchTerm)
  );

  const handleCreateNewContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;
    onAddNewContact(newName.trim(), newPhone.trim() || '+1 (555) 000-0000', newAbout.trim());
    setIsAddingCustom(false);
  };

  const isDark = theme === 'dark';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div
        className={`relative w-full max-w-md rounded-2xl overflow-hidden shadow-2xl flex flex-col h-[560px] border ${
          isDark
            ? 'bg-[#111b21] border-slate-800 text-white'
            : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        {/* Header */}
        <div
          className={`flex items-center justify-between p-4 border-b ${
            isDark ? 'bg-[#202c33] border-slate-700' : 'bg-[#008069] text-white border-emerald-700'
          }`}
        >
          <div className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-[#00a884] dark:text-[#00a884]" />
            <h3 className="font-semibold text-base">New Chat</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        {isAddingCustom ? (
          <form onSubmit={handleCreateNewContact} className="p-6 flex flex-col gap-4 flex-1">
            <h4 className="text-sm font-semibold">Add New Contact</h4>
            <div>
              <label className="text-xs text-slate-400 block mb-1">Full Name</label>
              <input
                type="text"
                required
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="e.g. Jordan Hayes"
                className={`w-full px-3 py-2 rounded-lg text-sm outline-none border ${
                  isDark ? 'bg-[#202c33] border-slate-700 text-white' : 'bg-slate-50 border-slate-300'
                } focus:border-[#00a884]`}
                autoFocus
              />
            </div>
            <div>
              <label className="text-xs text-slate-400 block mb-1">Phone Number</label>
              <input
                type="text"
                value={newPhone}
                onChange={(e) => setNewPhone(e.target.value)}
                placeholder="e.g. +1 (555) 923-1122"
                className={`w-full px-3 py-2 rounded-lg text-sm outline-none border ${
                  isDark ? 'bg-[#202c33] border-slate-700 text-white' : 'bg-slate-50 border-slate-300'
                } focus:border-[#00a884]`}
              />
            </div>
            <div>
              <label className="text-xs text-slate-400 block mb-1">About / Bio</label>
              <input
                type="text"
                value={newAbout}
                onChange={(e) => setNewAbout(e.target.value)}
                className={`w-full px-3 py-2 rounded-lg text-sm outline-none border ${
                  isDark ? 'bg-[#202c33] border-slate-700 text-white' : 'bg-slate-50 border-slate-300'
                } focus:border-[#00a884]`}
              />
            </div>

            <div className="mt-auto flex items-center justify-end gap-3 pt-4 border-t border-slate-700/50">
              <button
                type="button"
                onClick={() => setIsAddingCustom(false)}
                className="px-4 py-2 text-xs font-medium rounded-lg text-slate-400 hover:text-white"
              >
                Back
              </button>
              <button
                type="submit"
                className="px-5 py-2 text-xs font-semibold rounded-lg bg-[#00a884] hover:bg-[#008f72] text-white shadow-md"
              >
                Save Contact & Chat
              </button>
            </div>
          </form>
        ) : (
          <div className="flex flex-col flex-1 overflow-hidden">
            {/* Search Bar */}
            <div className="p-3 border-b border-slate-700/40">
              <div
                className={`flex items-center gap-2 px-3 py-2 rounded-lg ${
                  isDark ? 'bg-[#202c33]' : 'bg-slate-100'
                }`}
              >
                <Search className="w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search name or number"
                  className="w-full bg-transparent text-sm outline-none placeholder-slate-400"
                />
              </div>
            </div>

            {/* Quick Action Buttons */}
            <div className="p-2 border-b border-slate-700/30 flex flex-col gap-1">
              <button
                onClick={() => {
                  onClose();
                  onOpenNewGroup();
                }}
                className={`flex items-center gap-3 p-3 rounded-xl transition-colors text-left ${
                  isDark ? 'hover:bg-[#202c33]' : 'hover:bg-slate-100'
                }`}
              >
                <div className="w-10 h-10 rounded-full bg-[#00a884] flex items-center justify-center text-white shrink-0">
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-sm font-semibold">New Group</div>
                  <div className="text-xs text-slate-400">Create a group chat with contacts</div>
                </div>
              </button>

              <button
                onClick={() => setIsAddingCustom(true)}
                className={`flex items-center gap-3 p-3 rounded-xl transition-colors text-left ${
                  isDark ? 'hover:bg-[#202c33]' : 'hover:bg-slate-100'
                }`}
              >
                <div className="w-10 h-10 rounded-full bg-emerald-700/60 flex items-center justify-center text-white shrink-0">
                  <UserPlus className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-sm font-semibold">New Contact</div>
                  <div className="text-xs text-slate-400">Save a new contact number</div>
                </div>
              </button>
            </div>

            {/* Contacts list */}
            <div className="flex-1 overflow-y-auto p-2">
              <div className="px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-slate-400">
                Contacts on SkaarChat
              </div>
              {filteredContacts.map((contact) => (
                <button
                  key={contact.id}
                  onClick={() => {
                    onSelectContact(contact.id);
                    onClose();
                  }}
                  className={`w-full flex items-center gap-3 p-2.5 rounded-xl transition-colors text-left ${
                    isDark ? 'hover:bg-[#202c33]' : 'hover:bg-slate-100'
                  }`}
                >
                  <div className="relative w-11 h-11 rounded-full overflow-hidden bg-slate-700 shrink-0">
                    {contact.avatar ? (
                      <img src={contact.avatar} alt={contact.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center font-bold text-white bg-emerald-800">
                        {contact.name[0]}
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-semibold truncate">{contact.name}</div>
                    <div className="text-xs text-slate-400 truncate">{contact.about}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
