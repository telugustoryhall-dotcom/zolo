import React, { useState, useEffect, useRef } from 'react';
import { Contact } from '../types/chat';
import { sound } from '../utils/audio';
import { Phone, Video, PhoneOff, Mic, MicOff, VideoOff, Volume2, VolumeX, Maximize2, Minimize2, User } from 'lucide-react';

interface CallModalProps {
  contact: Contact;
  type: 'audio' | 'video';
  isIncoming?: boolean;
  onClose: (durationStr?: string) => void;
}

export const CallModal: React.FC<CallModalProps> = ({
  contact,
  type,
  isIncoming = false,
  onClose,
}) => {
  const [callState, setCallState] = useState<'ringing' | 'connected'>(isIncoming ? 'ringing' : 'ringing');
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoEnabled, setIsVideoEnabled] = useState(type === 'video');
  const [isSpeakerOn, setIsSpeakerOn] = useState(true);
  const [duration, setDuration] = useState(0);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [cameraError, setCameraError] = useState(false);

  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Handle ringing sound
  useEffect(() => {
    sound.startRinging();

    // If outgoing call, automatically connect after 3 seconds for smooth simulation
    let connectTimeout: number | null = null;
    if (!isIncoming) {
      connectTimeout = window.setTimeout(() => {
        sound.stopRinging();
        setCallState('connected');
      }, 3200);
    }

    return () => {
      sound.stopRinging();
      if (connectTimeout) clearTimeout(connectTimeout);
      stopCamera();
    };
  }, [isIncoming]);

  // Handle call timer when connected
  useEffect(() => {
    let interval: number | null = null;
    if (callState === 'connected') {
      interval = window.setInterval(() => {
        setDuration((prev) => prev + 1);
      }, 1000);

      // Start camera if video call
      if (type === 'video') {
        startCamera();
      }
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [callState, type]);

  const startCamera = async () => {
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        streamRef.current = stream;
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream;
        }
      }
    } catch {
      // Permission denied or no camera available; graceful simulated fallback
      setCameraError(true);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
  };

  const handleAnswer = () => {
    sound.stopRinging();
    setCallState('connected');
  };

  const handleEndCall = () => {
    sound.stopRinging();
    stopCamera();
    const mins = Math.floor(duration / 60);
    const secs = duration % 60;
    const durationStr = duration > 0 ? `${mins}m ${secs < 10 ? '0' : ''}${secs}s` : undefined;
    onClose(durationStr);
  };

  const toggleVideo = () => {
    if (isVideoEnabled) {
      stopCamera();
      setIsVideoEnabled(false);
    } else {
      setIsVideoEnabled(true);
      startCamera();
    }
  };

  const formatTimer = (s: number) => {
    const mins = Math.floor(s / 60);
    const secs = s % 60;
    return `${mins < 10 ? '0' : ''}${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
      <div
        className={`relative w-full overflow-hidden rounded-3xl bg-[#111b21] text-white shadow-2xl transition-all duration-300 flex flex-col justify-between ${
          isFullScreen
            ? 'h-[95vh] max-w-5xl'
            : 'h-[580px] max-w-md md:max-w-xl'
        }`}
      >
        {/* Top Controls Bar */}
        <div className="relative z-20 flex items-center justify-between p-4 bg-gradient-to-b from-black/60 to-transparent">
          <div className="flex items-center gap-2">
            <span className="text-xs uppercase tracking-wider font-semibold text-emerald-400">
              End-to-End Encrypted
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsFullScreen(!isFullScreen)}
              className="p-2 rounded-full hover:bg-white/10 transition-colors"
              title={isFullScreen ? 'Exit full screen' : 'Full screen'}
            >
              {isFullScreen ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Video or Audio Stage */}
        <div className="relative flex-1 flex flex-col items-center justify-center p-6 text-center">
          {type === 'video' && isVideoEnabled ? (
            <div className="absolute inset-0 w-full h-full bg-slate-900 flex items-center justify-center overflow-hidden">
              {/* Contact video simulation or placeholder */}
              {contact.avatar ? (
                <img
                  src={contact.avatar}
                  alt={contact.name}
                  className="w-full h-full object-cover filter brightness-75 scale-105 transition-transform"
                />
              ) : (
                <div className="w-full h-full bg-gradient-to-tr from-slate-900 via-slate-800 to-emerald-950 flex items-center justify-center">
                  <div className="w-32 h-32 rounded-full bg-emerald-600/30 flex items-center justify-center text-4xl font-bold">
                    {contact.name[0]}
                  </div>
                </div>
              )}

              {/* Local Video Inset PiP */}
              <div className="absolute bottom-6 right-6 w-32 h-44 sm:w-40 sm:h-56 rounded-2xl overflow-hidden shadow-2xl border-2 border-white/20 bg-black z-20">
                {cameraError ? (
                  <div className="w-full h-full flex flex-col items-center justify-center bg-slate-800 p-2 text-center">
                    <User className="w-8 h-8 text-slate-400 mb-1" />
                    <span className="text-[10px] text-slate-300">You</span>
                  </div>
                ) : (
                  <video
                    ref={localVideoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover transform -scale-x-100"
                  />
                )}
                <div className="absolute top-2 left-2 text-[10px] bg-black/60 px-1.5 py-0.5 rounded text-white">
                  You
                </div>
              </div>

              {/* Contact overlay name & status */}
              <div className="absolute top-6 left-6 z-10 text-left bg-black/40 backdrop-blur-sm px-3 py-1.5 rounded-xl">
                <h3 className="text-base font-bold text-white drop-shadow">{contact.name}</h3>
                <span className="text-xs text-slate-300">
                  {callState === 'ringing' ? 'Ringing...' : formatTimer(duration)}
                </span>
              </div>
            </div>
          ) : (
            /* Audio Call Stage */
            <div className="flex flex-col items-center justify-center gap-4 z-10">
              <div className="relative">
                {/* Pulsing rings when ringing */}
                {callState === 'ringing' && (
                  <>
                    <div className="absolute inset-0 rounded-full bg-emerald-500/20 animate-ping opacity-75" />
                    <div className="absolute -inset-4 rounded-full bg-emerald-500/10 animate-pulse" />
                  </>
                )}
                {contact.avatar ? (
                  <img
                    src={contact.avatar}
                    alt={contact.name}
                    className="w-28 h-28 sm:w-36 sm:h-36 rounded-full object-cover border-4 border-slate-700 shadow-xl"
                  />
                ) : (
                  <div className="w-28 h-28 sm:w-36 sm:h-36 rounded-full bg-emerald-700 flex items-center justify-center text-4xl font-bold shadow-xl">
                    {contact.name[0]}
                  </div>
                )}
              </div>

              <div>
                <h2 className="text-2xl font-bold tracking-tight text-white">{contact.name}</h2>
                <p className="text-sm text-slate-400 mt-1">
                  {callState === 'ringing'
                    ? isIncoming
                      ? 'Incoming SkaarChat call...'
                      : 'Ringing...'
                    : formatTimer(duration)}
                </p>
              </div>

              {/* Connected Audio Waveform Animation */}
              {callState === 'connected' && (
                <div className="flex items-center gap-1.5 h-6 mt-2">
                  <span className="w-1 bg-[#00a884] rounded-full animate-wave-1 h-3" />
                  <span className="w-1 bg-[#00a884] rounded-full animate-wave-2 h-5" />
                  <span className="w-1 bg-[#00a884] rounded-full animate-wave-3 h-4" />
                  <span className="w-1 bg-[#00a884] rounded-full animate-wave-4 h-6" />
                  <span className="w-1 bg-[#00a884] rounded-full animate-wave-2 h-3" />
                </div>
              )}
            </div>
          )}
        </div>

        {/* Bottom Call Controls */}
        <div className="relative z-20 flex items-center justify-center gap-4 sm:gap-6 p-6 bg-gradient-to-t from-black/80 via-black/40 to-transparent">
          {callState === 'ringing' && isIncoming ? (
            /* Incoming Actions */
            <div className="flex items-center gap-12">
              <button
                onClick={handleEndCall}
                className="flex flex-col items-center gap-2 group"
              >
                <div className="w-16 h-16 rounded-full bg-rose-600 hover:bg-rose-700 flex items-center justify-center transition-transform active:scale-90 shadow-lg">
                  <PhoneOff className="w-7 h-7 text-white" />
                </div>
                <span className="text-xs text-slate-300 font-medium">Decline</span>
              </button>

              <button
                onClick={handleAnswer}
                className="flex flex-col items-center gap-2 group"
              >
                <div className="w-16 h-16 rounded-full bg-emerald-500 hover:bg-emerald-600 flex items-center justify-center transition-transform active:scale-90 shadow-lg shadow-emerald-500/30">
                  <Phone className="w-7 h-7 text-white animate-bounce" />
                </div>
                <span className="text-xs text-slate-300 font-medium">Accept</span>
              </button>
            </div>
          ) : (
            /* Connected Actions */
            <>
              {/* Mic Toggle */}
              <button
                onClick={() => setIsMuted(!isMuted)}
                className={`p-4 rounded-full transition-transform active:scale-90 ${
                  isMuted ? 'bg-rose-500/80 text-white' : 'bg-white/15 hover:bg-white/25 text-white'
                }`}
                title={isMuted ? 'Unmute microphone' : 'Mute microphone'}
              >
                {isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
              </button>

              {/* Video Toggle */}
              <button
                onClick={toggleVideo}
                className={`p-4 rounded-full transition-transform active:scale-90 ${
                  !isVideoEnabled ? 'bg-rose-500/80 text-white' : 'bg-white/15 hover:bg-white/25 text-white'
                }`}
                title={isVideoEnabled ? 'Turn video off' : 'Turn video on'}
              >
                {isVideoEnabled ? <Video className="w-6 h-6" /> : <VideoOff className="w-6 h-6" />}
              </button>

              {/* Speaker Toggle */}
              <button
                onClick={() => setIsSpeakerOn(!isSpeakerOn)}
                className={`p-4 rounded-full transition-transform active:scale-90 ${
                  !isSpeakerOn ? 'bg-rose-500/80 text-white' : 'bg-white/15 hover:bg-white/25 text-white'
                }`}
                title={isSpeakerOn ? 'Turn speaker off' : 'Turn speaker on'}
              >
                {isSpeakerOn ? <Volume2 className="w-6 h-6" /> : <VolumeX className="w-6 h-6" />}
              </button>

              {/* End Call Button */}
              <button
                onClick={handleEndCall}
                className="p-4 rounded-full bg-rose-600 hover:bg-rose-700 text-white transition-transform active:scale-90 shadow-xl"
                title="End call"
              >
                <PhoneOff className="w-7 h-7" />
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
