import React, { useState } from 'react';
import { Contact, StatusStory, CallLog, Message, UserProfile } from '../types/chat';
import {
  MessageSquare, CircleDashed, Phone, Star, Settings, Plus, Search,
  Pin, BellOff, Archive, Check, CheckCheck, Sun, Moon, Volume2, VolumeX,
  User, Shield, CornerDownRight, RotateCcw, CheckCircle2, ChevronRight,
  Filter, MoreVertical, PhoneCall, Video, PhoneIncoming, PhoneOutgoing, PhoneMissed, X, Camera
} from 'lucide-react';
import { AvatarPickerModal } from './AvatarPickerModal';

interface SidebarProps {
  contacts: Contact[];
  activeContactId: string | null;
  statuses: StatusStory[];
  callLogs: CallLog[];
  allMessages: Record<string, Message[]>;
  currentUser: UserProfile;
  theme: 'dark' | 'light';
  typingContactId?: string | null;
  onSelectContact: (id: string) => void;
  onOpenNewChat: () => void;
  onOpenNewGroup: () => void;
  onOpenStatusViewer: (index: number) => void;
  onOpenStatusCreator: () => void;
  onStartCall: (contactId: string, type: 'audio' | 'video') => void;
  onTogglePin: (contactId: string) => void;
  onToggleMute: (contactId: string) => void;
  onToggleArchive: (contactId: string) => void;
  onToggleTheme: () => void;
  onUpdateProfile: (updated: Partial<UserProfile>) => void;
  onResetData: () => void;
}

type TabType = 'chats' | 'status' | 'calls' | 'starred' | 'archived' | 'settings';
type ChatFilterType = 'all' | 'unread' | 'groups';

export const Sidebar: React.FC<SidebarProps> = ({
  contacts,
  activeContactId,
  statuses,
  callLogs,
  allMessages,
  currentUser,
  theme,
  typingContactId,
  onSelectContact,
  onOpenNewChat,
  onOpenNewGroup,
  onOpenStatusViewer,
  onOpenStatusCreator,
  onStartCall,
  onTogglePin,
  onToggleMute,
  onToggleArchive,
  onToggleTheme,
  onUpdateProfile,
  onResetData,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('chats');
  const [chatFilter, setChatFilter] = useState<ChatFilterType>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showMoreMenu, setShowMoreMenu] = useState(false);

  // Settings editing state
  const [editName, setEditName] = useState(currentUser.name);
  const [editAbout, setEditAbout] = useState(currentUser.about);
  const [editPhone, setEditPhone] = useState(currentUser.phone);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [isProfileAvatarPickerOpen, setIsProfileAvatarPickerOpen] = useState(false);

  const isDark = theme === 'dark';

  // Total unread messages count
  const totalUnreadCount = contacts.reduce((sum, c) => sum + (c.unreadCount || 0), 0);
  const unreadStatusesCount = statuses.filter((s) => !s.viewed && s.contactId !== 'user').length;

  // Helper to highlight matching characters in contact name
  const renderHighlightedName = (name: string, query: string) => {
    const trimmed = query.trim();
    if (!trimmed) return name;
    const index = name.toLowerCase().indexOf(trimmed.toLowerCase());
    if (index === -1) return name;
    const before = name.substring(0, index);
    const match = name.substring(index, index + trimmed.length);
    const after = name.substring(index + trimmed.length);
    return (
      <>
        {before}
        <span className="bg-[#00a884]/25 text-[#00a884] font-bold rounded px-0.5">{match}</span>
        {after}
      </>
    );
  };

  // Filter contacts by name as user types
  const visibleContacts = contacts
    .filter((c) => {
      if (activeTab === 'archived') {
        return c.isArchived;
      }
      return !c.isArchived;
    })
    .filter((c) => {
      if (chatFilter === 'unread') return c.unreadCount > 0;
      if (chatFilter === 'groups') return c.isGroup;
      return true;
    })
    .filter((c) => {
      const q = searchQuery.toLowerCase().trim();
      if (!q) return true;
      return c.name.toLowerCase().includes(q);
    })
    .sort((a, b) => {
      // Pinned contacts first
      if (a.isPinned && !b.isPinned) return -1;
      if (!a.isPinned && b.isPinned) return 1;
      return 0;
    });

  // Collect all starred messages
  const starredMessagesList: { message: Message; contact: Contact }[] = [];
  Object.entries(allMessages).forEach(([chatId, msgs]) => {
    const contact = contacts.find((c) => c.id === chatId);
    if (contact) {
      msgs.forEach((m) => {
        if (m.isStarred) {
          starredMessagesList.push({ message: m, contact });
        }
      });
    }
  });

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile({
      name: editName.trim() || currentUser.name,
      about: editAbout.trim() || currentUser.about,
      phone: editPhone.trim() || currentUser.phone,
    });
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  return (
    <div className="flex h-full w-full md:w-[380px] lg:w-[440px] shrink-0 border-r select-none overflow-hidden transition-colors duration-200">
      {/* 1. Left Icon Navigation Rail */}
      <div
        className={`w-14 sm:w-16 flex flex-col items-center justify-between py-4 border-r shrink-0 z-20 ${
          isDark ? 'bg-[#202c33] border-slate-800 text-slate-300' : 'bg-[#f0f2f5] border-slate-200 text-slate-600'
        }`}
      >
        {/* Top Destination Icons */}
        <div className="flex flex-col items-center gap-4 w-full">
          {/* Chats Tab */}
          <button
            onClick={() => setActiveTab('chats')}
            className={`relative p-2.5 rounded-xl transition-all ${
              activeTab === 'chats'
                ? isDark
                  ? 'bg-slate-700/60 text-[#00a884]'
                  : 'bg-slate-200 text-[#008069]'
                : 'hover:bg-slate-700/20 text-slate-400'
            }`}
            title="Chats"
          >
            <MessageSquare className="w-5 h-5" />
            {totalUnreadCount > 0 && (
              <span className="absolute -top-1 -right-1 px-1.5 py-0.2 min-w-[18px] text-[10px] font-bold bg-[#00a884] text-white rounded-full flex items-center justify-center">
                {totalUnreadCount}
              </span>
            )}
          </button>

          {/* Status Tab */}
          <button
            onClick={() => setActiveTab('status')}
            className={`relative p-2.5 rounded-xl transition-all ${
              activeTab === 'status'
                ? isDark
                  ? 'bg-slate-700/60 text-[#00a884]'
                  : 'bg-slate-200 text-[#008069]'
                : 'hover:bg-slate-700/20 text-slate-400'
            }`}
            title="Status"
          >
            <CircleDashed className="w-5 h-5" />
            {unreadStatusesCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#00a884]" />
            )}
          </button>

          {/* Calls Tab */}
          <button
            onClick={() => setActiveTab('calls')}
            className={`relative p-2.5 rounded-xl transition-all ${
              activeTab === 'calls'
                ? isDark
                  ? 'bg-slate-700/60 text-[#00a884]'
                  : 'bg-slate-200 text-[#008069]'
                : 'hover:bg-slate-700/20 text-slate-400'
            }`}
            title="Calls"
          >
            <Phone className="w-5 h-5" />
          </button>

          {/* Starred Messages Tab */}
          <button
            onClick={() => setActiveTab('starred')}
            className={`relative p-2.5 rounded-xl transition-all ${
              activeTab === 'starred'
                ? isDark
                  ? 'bg-slate-700/60 text-amber-400'
                  : 'bg-slate-200 text-amber-500'
                : 'hover:bg-slate-700/20 text-slate-400'
            }`}
            title="Starred Messages"
          >
            <Star className="w-5 h-5" />
          </button>
        </div>

        {/* Bottom Destination Icons */}
        <div className="flex flex-col items-center gap-3 w-full">
          {/* Theme Switcher */}
          <button
            onClick={onToggleTheme}
            className="p-2.5 rounded-xl hover:bg-slate-700/20 text-slate-400 transition-colors"
            title={isDark ? 'Switch to Light Theme' : 'Switch to Dark Theme'}
          >
            {isDark ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5 text-indigo-600" />}
          </button>

          {/* Settings Tab */}
          <button
            onClick={() => setActiveTab('settings')}
            className={`p-2.5 rounded-xl transition-all ${
              activeTab === 'settings'
                ? isDark
                  ? 'bg-slate-700/60 text-[#00a884]'
                  : 'bg-slate-200 text-[#008069]'
                : 'hover:bg-slate-700/20 text-slate-400'
            }`}
            title="Settings"
          >
            <Settings className="w-5 h-5" />
          </button>

          {/* User Profile Avatar */}
          <div
            onClick={() => setActiveTab('settings')}
            className="w-9 h-9 rounded-full overflow-hidden cursor-pointer border-2 border-emerald-500 hover:opacity-85 transition-opacity"
            title="My Profile"
          >
            {currentUser.avatar ? (
              <img src={currentUser.avatar} alt={currentUser.name} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full bg-emerald-700 text-white font-bold flex items-center justify-center text-xs">
                {currentUser.name[0]}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 2. Subpanel View Content */}
      <div
        className={`flex-1 flex flex-col h-full overflow-hidden ${
          isDark ? 'bg-[#111b21] text-white' : 'bg-white text-slate-900'
        }`}
      >
        {/* A. CHATS SUBPANEL */}
        {activeTab === 'chats' && (
          <div className="flex flex-col h-full overflow-hidden">
            {/* Header */}
            <div className="p-3.5 flex items-center justify-between border-b border-slate-700/20">
              <div className="flex items-center gap-2">
                <span className="text-xl font-bold tracking-tight text-[#00a884]">
                  SkaarChat
                </span>
              </div>

              <div className="flex items-center gap-1 text-slate-400">
                <button
                  onClick={onOpenNewChat}
                  className="p-2 rounded-full hover:bg-slate-700/20 hover:text-white transition-colors"
                  title="New Chat"
                >
                  <Plus className="w-5 h-5" />
                </button>

                <div className="relative">
                  <button
                    onClick={() => setShowMoreMenu(!showMoreMenu)}
                    className="p-2 rounded-full hover:bg-slate-700/20 hover:text-white transition-colors"
                    title="Menu"
                  >
                    <MoreVertical className="w-5 h-5" />
                  </button>

                  {showMoreMenu && (
                    <div
                      className={`absolute right-0 top-10 w-48 py-2 rounded-xl shadow-xl z-50 border ${
                        isDark ? 'bg-[#233138] border-slate-700 text-slate-200' : 'bg-white border-slate-200 text-slate-800'
                      }`}
                    >
                      <button
                        onClick={() => {
                          setShowMoreMenu(false);
                          onOpenNewGroup();
                        }}
                        className="w-full text-left px-4 py-2 text-xs font-medium hover:bg-slate-700/30"
                      >
                        New Group
                      </button>
                      <button
                        onClick={() => {
                          setShowMoreMenu(false);
                          setActiveTab('archived');
                        }}
                        className="w-full text-left px-4 py-2 text-xs font-medium hover:bg-slate-700/30"
                      >
                        Archived Chats
                      </button>
                      <button
                        onClick={() => {
                          setShowMoreMenu(false);
                          setActiveTab('starred');
                        }}
                        className="w-full text-left px-4 py-2 text-xs font-medium hover:bg-slate-700/30"
                      >
                        Starred Messages
                      </button>
                      <button
                        onClick={() => {
                          setShowMoreMenu(false);
                          setActiveTab('settings');
                        }}
                        className="w-full text-left px-4 py-2 text-xs font-medium hover:bg-slate-700/30"
                      >
                        Settings
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Search & Filter Bar */}
            <div className="p-3 flex flex-col gap-2 border-b border-slate-700/20">
              <div
                className={`relative flex items-center gap-2.5 px-3 py-2 rounded-xl transition-all border ${
                  isDark
                    ? 'bg-[#202c33] border-transparent focus-within:border-[#00a884]'
                    : 'bg-slate-100 border-transparent focus-within:border-[#008069] focus-within:bg-white focus-within:shadow-sm'
                }`}
              >
                <Search
                  className={`w-4 h-4 shrink-0 transition-colors ${
                    searchQuery.trim() ? 'text-[#00a884]' : 'text-slate-400'
                  }`}
                />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Escape') setSearchQuery('');
                  }}
                  placeholder="Search contacts by name..."
                  aria-label="Search contacts by name"
                  className="w-full bg-transparent text-xs sm:text-sm outline-none placeholder-slate-400"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery('')}
                    className="p-1 rounded-full hover:bg-slate-700/30 text-slate-400 hover:text-white transition-colors shrink-0"
                    title="Clear search"
                    aria-label="Clear search"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Real-time search match feedback */}
              {searchQuery.trim() && (
                <div className="flex items-center justify-between px-1 text-[11px] text-slate-400">
                  <span>
                    {visibleContacts.length} {visibleContacts.length === 1 ? 'contact' : 'contacts'} matching &ldquo;{searchQuery}&rdquo;
                  </span>
                  <button
                    type="button"
                    onClick={() => setSearchQuery('')}
                    className="text-[#00a884] hover:underline font-semibold"
                  >
                    Clear filter
                  </button>
                </div>
              )}

              {/* Filter Pills */}
              <div className="flex items-center gap-1.5 pt-0.5">
                {(['all', 'unread', 'groups'] as const).map((filter) => (
                  <button
                    key={filter}
                    onClick={() => setChatFilter(filter)}
                    className={`px-3 py-1 rounded-full text-xs font-medium capitalize transition-colors ${
                      chatFilter === filter
                        ? 'bg-[#00a884] text-white shadow-sm'
                        : isDark
                        ? 'bg-[#202c33] text-slate-300 hover:bg-slate-700'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {filter === 'all' ? 'All' : filter}
                  </button>
                ))}
              </div>
            </div>

            {/* Chats List */}
            <div className="flex-1 overflow-y-auto">
              {visibleContacts.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-400 flex flex-col items-center justify-center gap-2">
                  <Search className="w-8 h-8 text-slate-500/50 mb-1" />
                  <p className="font-semibold text-sm text-slate-300">No contacts found</p>
                  <p className="text-slate-400 max-w-xs">
                    {searchQuery.trim()
                      ? `No contacts match "${searchQuery.trim()}"`
                      : 'No conversations found in this view.'}
                  </p>
                  {searchQuery.trim() && (
                    <button
                      type="button"
                      onClick={() => setSearchQuery('')}
                      className="mt-2 px-3.5 py-1.5 text-xs font-semibold rounded-full bg-[#00a884] text-white hover:bg-[#008f72] transition-colors"
                    >
                      Clear search
                    </button>
                  )}
                </div>
              ) : (
                visibleContacts.map((contact) => {
                  const isActive = activeContactId === contact.id;
                  const chatMsgs = allMessages[contact.id] || [];
                  const lastMsg = chatMsgs[chatMsgs.length - 1];

                  return (
                    <div
                      key={contact.id}
                      onClick={() => onSelectContact(contact.id)}
                      className={`relative flex items-center gap-3 px-3.5 py-3 cursor-pointer border-b transition-colors group ${
                        isActive
                          ? isDark
                            ? 'bg-[#2a3942] border-slate-700/50'
                            : 'bg-slate-100 border-slate-200'
                          : isDark
                          ? 'border-slate-800/40 hover:bg-[#202c33]'
                          : 'border-slate-100 hover:bg-slate-50'
                      }`}
                    >
                      {/* Avatar */}
                      <div className="relative w-12 h-12 rounded-full overflow-hidden bg-slate-700 shrink-0">
                        {contact.avatar ? (
                          <img
                            src={contact.avatar}
                            alt={contact.name}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center font-bold text-white bg-emerald-800">
                            {contact.name[0]}
                          </div>
                        )}
                        {contact.online && (
                          <div className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 border-2 border-[#111b21]" />
                        )}
                      </div>

                      {/* Info & Snippet */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-0.5">
                          <h4 className="text-sm font-semibold truncate leading-tight">
                            {renderHighlightedName(contact.name, searchQuery)}
                          </h4>
                          <span className="text-[11px] text-slate-400 shrink-0 ml-2">
                            {lastMsg ? lastMsg.timestamp : ''}
                          </span>
                        </div>

                        <div className="flex items-center justify-between">
                          <p className="text-xs text-slate-400 truncate pr-2">
                            {contact.isTyping || typingContactId === contact.id ? (
                              <span className="text-[#00a884] font-medium">typing...</span>
                            ) : lastMsg ? (
                              <span>
                                {lastMsg.senderId === 'user' && (
                                  <span className="mr-1 inline-block align-middle">
                                    {lastMsg.status === 'read' ? (
                                      <CheckCheck className="w-3.5 h-3.5 text-[#53bdeb] inline" />
                                    ) : (
                                      <Check className="w-3.5 h-3.5 text-slate-400 inline" />
                                    )}
                                  </span>
                                )}
                                {lastMsg.mediaType === 'audio'
                                  ? '🎤 Voice note'
                                  : lastMsg.mediaType === 'image'
                                  ? '📷 Photo'
                                  : lastMsg.mediaType === 'poll'
                                  ? '📊 Poll'
                                  : lastMsg.mediaType === 'location'
                                  ? '📍 Location'
                                  : lastMsg.mediaType === 'document'
                                  ? '📄 Document'
                                  : lastMsg.text}
                              </span>
                            ) : (
                              contact.about
                            )}
                          </p>

                          <div className="flex items-center gap-1.5 shrink-0">
                            {contact.isMuted && (
                              <BellOff className="w-3.5 h-3.5 text-slate-400" />
                            )}
                            {contact.isPinned && (
                              <Pin className="w-3.5 h-3.5 text-slate-400 rotate-45" />
                            )}
                            {contact.unreadCount > 0 && (
                              <span className="px-1.5 py-0.5 min-w-[18px] text-[10px] font-bold bg-[#00a884] text-white rounded-full flex items-center justify-center">
                                {contact.unreadCount}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Hover action menu pills */}
                      <div className="absolute right-2 top-2 hidden group-hover:flex items-center gap-1 bg-[#202c33] p-1 rounded-lg border border-slate-700/60 shadow-md">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onTogglePin(contact.id);
                          }}
                          className={`p-1 hover:text-[#00a884] transition-colors ${
                            contact.isPinned ? 'text-[#00a884]' : 'text-slate-400'
                          }`}
                          title={contact.isPinned ? 'Unpin chat' : 'Pin chat'}
                        >
                          <Pin className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onToggleMute(contact.id);
                          }}
                          className={`p-1 hover:text-[#00a884] transition-colors ${
                            contact.isMuted ? 'text-amber-400' : 'text-slate-400'
                          }`}
                          title={contact.isMuted ? 'Unmute' : 'Mute'}
                        >
                          <BellOff className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onToggleArchive(contact.id);
                          }}
                          className="p-1 text-slate-400 hover:text-white transition-colors"
                          title="Archive chat"
                        >
                          <Archive className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* B. STATUS SUBPANEL */}
        {activeTab === 'status' && (
          <div className="flex flex-col h-full overflow-hidden">
            <div className="p-4 border-b border-slate-700/20 flex items-center justify-between">
              <h3 className="text-lg font-bold">Status</h3>
              <button
                onClick={onOpenStatusCreator}
                className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-[#00a884] hover:bg-[#008f72] text-white text-xs font-semibold shadow-md transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>Add Status</span>
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-3 space-y-4">
              {/* My Status */}
              <div
                onClick={onOpenStatusCreator}
                className={`flex items-center gap-3 p-3 rounded-2xl cursor-pointer transition-colors ${
                  isDark ? 'hover:bg-[#202c33]' : 'hover:bg-slate-100'
                }`}
              >
                <div className="relative w-12 h-12 rounded-full bg-emerald-700 flex items-center justify-center font-bold text-white shrink-0">
                  {currentUser.name[0]}
                  <div className="absolute bottom-0 right-0 w-4 h-4 rounded-full bg-[#00a884] text-white flex items-center justify-center border-2 border-[#111b21]">
                    <Plus className="w-3 h-3 stroke-[3]" />
                  </div>
                </div>
                <div>
                  <h4 className="text-sm font-semibold">My status</h4>
                  <p className="text-xs text-slate-400">Click to add a status update</p>
                </div>
              </div>

              {/* Recent Updates */}
              <div>
                <div className="text-xs font-bold uppercase tracking-wider text-slate-400 px-3 mb-2">
                  Recent updates
                </div>
                <div className="space-y-1">
                  {statuses
                    .filter((s) => !s.viewed)
                    .map((status, index) => (
                      <div
                        key={status.id}
                        onClick={() => onOpenStatusViewer(index)}
                        className={`flex items-center gap-3 p-3 rounded-2xl cursor-pointer transition-colors ${
                          isDark ? 'hover:bg-[#202c33]' : 'hover:bg-slate-100'
                        }`}
                      >
                        {/* Emerald Ring Avatar */}
                        <div className="w-12 h-12 rounded-full p-0.5 border-2 border-[#00a884] shrink-0 overflow-hidden">
                          {status.contactAvatar ? (
                            <img
                              src={status.contactAvatar}
                              alt={status.contactName}
                              className="w-full h-full rounded-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full rounded-full bg-slate-700 flex items-center justify-center text-white font-bold">
                              {status.contactName[0]}
                            </div>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="text-sm font-semibold truncate">{status.contactName}</h4>
                          <p className="text-xs text-slate-400">{status.timestamp}</p>
                        </div>
                      </div>
                    ))}
                </div>
              </div>

              {/* Viewed Updates */}
              {statuses.filter((s) => s.viewed).length > 0 && (
                <div>
                  <div className="text-xs font-bold uppercase tracking-wider text-slate-400 px-3 mb-2">
                    Viewed updates
                  </div>
                  <div className="space-y-1">
                    {statuses
                      .filter((s) => s.viewed)
                      .map((status, index) => (
                        <div
                          key={status.id}
                          onClick={() => onOpenStatusViewer(index)}
                          className={`flex items-center gap-3 p-3 rounded-2xl cursor-pointer transition-colors opacity-75 ${
                            isDark ? 'hover:bg-[#202c33]' : 'hover:bg-slate-100'
                          }`}
                        >
                          <div className="w-12 h-12 rounded-full p-0.5 border-2 border-slate-600 shrink-0 overflow-hidden">
                            {status.contactAvatar ? (
                              <img
                                src={status.contactAvatar}
                                alt={status.contactName}
                                className="w-full h-full rounded-full object-cover"
                              />
                            ) : (
                              <div className="w-full h-full rounded-full bg-slate-700 flex items-center justify-center text-white font-bold">
                                {status.contactName[0]}
                              </div>
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <h4 className="text-sm font-semibold truncate">{status.contactName}</h4>
                            <p className="text-xs text-slate-400">{status.timestamp}</p>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* C. CALLS SUBPANEL */}
        {activeTab === 'calls' && (
          <div className="flex flex-col h-full overflow-hidden">
            <div className="p-4 border-b border-slate-700/20 flex items-center justify-between">
              <h3 className="text-lg font-bold">Calls</h3>
              <button
                onClick={onOpenNewChat}
                className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-[#00a884] hover:bg-[#008f72] text-white text-xs font-semibold shadow-md transition-colors"
              >
                <PhoneCall className="w-4 h-4" />
                <span>New Call</span>
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-3 space-y-1">
              {callLogs.map((log) => (
                <div
                  key={log.id}
                  className={`flex items-center justify-between p-3 rounded-2xl transition-colors ${
                    isDark ? 'hover:bg-[#202c33]' : 'hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-full overflow-hidden bg-slate-700 shrink-0">
                      {log.contactAvatar ? (
                        <img src={log.contactAvatar} alt={log.contactName} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center font-bold text-white bg-emerald-800">
                          {log.contactName[0]}
                        </div>
                      )}
                    </div>

                    <div>
                      <h4 className="text-sm font-semibold">{log.contactName}</h4>
                      <div className="flex items-center gap-1.5 text-xs text-slate-400">
                        {log.direction === 'incoming' && (
                          <PhoneIncoming className="w-3.5 h-3.5 text-emerald-400" />
                        )}
                        {log.direction === 'outgoing' && (
                          <PhoneOutgoing className="w-3.5 h-3.5 text-blue-400" />
                        )}
                        {log.direction === 'missed' && (
                          <PhoneMissed className="w-3.5 h-3.5 text-rose-500" />
                        )}
                        <span>{log.timestamp}</span>
                        {log.duration && <span>· {log.duration}</span>}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onStartCall(log.contactId, log.type)}
                      className="p-2 rounded-full hover:bg-slate-700/20 text-[#00a884]"
                      title={`Call ${log.contactName}`}
                    >
                      {log.type === 'video' ? <Video className="w-5 h-5" /> : <Phone className="w-5 h-5" />}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* D. STARRED MESSAGES SUBPANEL */}
        {activeTab === 'starred' && (
          <div className="flex flex-col h-full overflow-hidden">
            <div className="p-4 border-b border-slate-700/20 flex items-center justify-between">
              <h3 className="text-lg font-bold">Starred Messages</h3>
              <span className="text-xs text-slate-400 font-medium">
                {starredMessagesList.length} starred
              </span>
            </div>

            <div className="flex-1 overflow-y-auto p-3 space-y-2">
              {starredMessagesList.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-400">
                  No starred messages yet. Hover over any message and click the star icon to save it here!
                </div>
              ) : (
                starredMessagesList.map(({ message, contact }) => (
                  <div
                    key={message.id}
                    onClick={() => onSelectContact(contact.id)}
                    className={`p-3 rounded-2xl cursor-pointer border transition-colors ${
                      isDark ? 'bg-[#202c33] border-slate-700/40 hover:bg-[#2a3942]' : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
                      <span className="font-semibold text-[#00a884]">{contact.name}</span>
                      <span>{message.timestamp}</span>
                    </div>
                    <p className="text-sm line-clamp-2">{message.text || `[${message.mediaType}]`}</p>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* E. ARCHIVED CHATS SUBPANEL */}
        {activeTab === 'archived' && (
          <div className="flex flex-col h-full overflow-hidden">
            <div className="p-4 border-b border-slate-700/20 flex items-center justify-between">
              <h3 className="text-lg font-bold">Archived Chats</h3>
              <button
                onClick={() => setActiveTab('chats')}
                className="text-xs text-[#00a884] font-semibold hover:underline"
              >
                Back to Chats
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-3">
              {visibleContacts.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-400">
                  No archived chats. Hover over any conversation and click the Archive icon to archive it.
                </div>
              ) : (
                visibleContacts.map((contact) => (
                  <div
                    key={contact.id}
                    onClick={() => onSelectContact(contact.id)}
                    className={`flex items-center justify-between p-3 rounded-2xl cursor-pointer ${
                      isDark ? 'hover:bg-[#202c33]' : 'hover:bg-slate-100'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 rounded-full overflow-hidden bg-slate-700">
                        {contact.avatar ? (
                          <img src={contact.avatar} alt={contact.name} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center font-bold text-white bg-emerald-800">
                            {contact.name[0]}
                          </div>
                        )}
                      </div>
                      <div>
                        <h4 className="text-sm font-semibold">{contact.name}</h4>
                        <p className="text-xs text-slate-400">{contact.about}</p>
                      </div>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleArchive(contact.id);
                      }}
                      className="p-2 text-xs font-semibold text-[#00a884] hover:underline"
                    >
                      Unarchive
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* F. SETTINGS SUBPANEL */}
        {activeTab === 'settings' && (
          <div className="flex flex-col h-full overflow-hidden">
            <div className="p-4 border-b border-slate-700/20">
              <h3 className="text-lg font-bold">Settings</h3>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-6">
              {/* Profile Card Form */}
              <form onSubmit={handleSaveProfile} className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-full bg-emerald-700 text-white font-bold text-2xl flex items-center justify-center shadow-md">
                    {currentUser.name[0]}
                  </div>
                  <div>
                    <h4 className="font-semibold text-base">{currentUser.name}</h4>
                    <p className="text-xs text-slate-400">{currentUser.phone}</p>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                    Your Name
                  </label>
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className={`w-full px-3 py-2 rounded-lg text-sm outline-none border ${
                      isDark ? 'bg-[#202c33] border-slate-700 text-white' : 'bg-slate-50 border-slate-300'
                    } focus:border-[#00a884]`}
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                    About
                  </label>
                  <input
                    type="text"
                    value={editAbout}
                    onChange={(e) => setEditAbout(e.target.value)}
                    className={`w-full px-3 py-2 rounded-lg text-sm outline-none border ${
                      isDark ? 'bg-[#202c33] border-slate-700 text-white' : 'bg-slate-50 border-slate-300'
                    } focus:border-[#00a884]`}
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                    Phone Number
                  </label>
                  <input
                    type="text"
                    value={editPhone}
                    onChange={(e) => setEditPhone(e.target.value)}
                    className={`w-full px-3 py-2 rounded-lg text-sm outline-none border ${
                      isDark ? 'bg-[#202c33] border-slate-700 text-white' : 'bg-slate-50 border-slate-300'
                    } focus:border-[#00a884]`}
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-[#00a884] hover:bg-[#008f72] text-white font-semibold text-xs transition-colors flex items-center justify-center gap-1.5 shadow-md"
                >
                  {saveSuccess ? (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Profile Saved!</span>
                    </>
                  ) : (
                    <span>Save Profile Changes</span>
                  )}
                </button>
              </form>

              {/* Toggles */}
              <div className="space-y-3 pt-3 border-t border-slate-700/30">
                <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Preferences
                </div>

                {/* Theme Toggle */}
                <div
                  onClick={onToggleTheme}
                  className={`flex items-center justify-between p-3 rounded-xl cursor-pointer ${
                    isDark ? 'hover:bg-[#202c33]' : 'hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    {isDark ? <Moon className="w-5 h-5 text-indigo-400" /> : <Sun className="w-5 h-5 text-amber-500" />}
                    <div>
                      <div className="text-sm font-semibold">Theme</div>
                      <div className="text-xs text-slate-400">{isDark ? 'Dark Mode' : 'Light Mode'}</div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400" />
                </div>

                {/* Sound Effects Toggle */}
                <div
                  onClick={() => onUpdateProfile({ soundEnabled: !currentUser.soundEnabled })}
                  className={`flex items-center justify-between p-3 rounded-xl cursor-pointer ${
                    isDark ? 'hover:bg-[#202c33]' : 'hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    {currentUser.soundEnabled ? (
                      <Volume2 className="w-5 h-5 text-[#00a884]" />
                    ) : (
                      <VolumeX className="w-5 h-5 text-slate-400" />
                    )}
                    <div>
                      <div className="text-sm font-semibold">Message & Call Sounds</div>
                      <div className="text-xs text-slate-400">Synthesized WhatsApp chimes</div>
                    </div>
                  </div>
                  <div
                    className={`w-9 h-5 flex items-center rounded-full p-0.5 transition-colors ${
                      currentUser.soundEnabled ? 'bg-[#00a884]' : 'bg-slate-600'
                    }`}
                  >
                    <div
                      className={`bg-white w-4 h-4 rounded-full shadow transform transition-transform ${
                        currentUser.soundEnabled ? 'translate-x-4' : 'translate-x-0'
                      }`}
                    />
                  </div>
                </div>

                {/* Enter is Send Toggle */}
                <div
                  onClick={() => onUpdateProfile({ enterIsSend: !currentUser.enterIsSend })}
                  className={`flex items-center justify-between p-3 rounded-xl cursor-pointer ${
                    isDark ? 'hover:bg-[#202c33]' : 'hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <CornerDownRight className="w-5 h-5 text-slate-400" />
                    <div>
                      <div className="text-sm font-semibold">Enter is Send</div>
                      <div className="text-xs text-slate-400">Pressing Enter sends message</div>
                    </div>
                  </div>
                  <div
                    className={`w-9 h-5 flex items-center rounded-full p-0.5 transition-colors ${
                      currentUser.enterIsSend ? 'bg-[#00a884]' : 'bg-slate-600'
                    }`}
                  >
                    <div
                      className={`bg-white w-4 h-4 rounded-full shadow transform transition-transform ${
                        currentUser.enterIsSend ? 'translate-x-4' : 'translate-x-0'
                      }`}
                    />
                  </div>
                </div>

                {/* Read Receipts */}
                <div
                  onClick={() => onUpdateProfile({ readReceipts: !currentUser.readReceipts })}
                  className={`flex items-center justify-between p-3 rounded-xl cursor-pointer ${
                    isDark ? 'hover:bg-[#202c33]' : 'hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <CheckCheck className="w-5 h-5 text-[#53bdeb]" />
                    <div>
                      <div className="text-sm font-semibold">Read Receipts</div>
                      <div className="text-xs text-slate-400">Show blue checkmarks</div>
                    </div>
                  </div>
                  <div
                    className={`w-9 h-5 flex items-center rounded-full p-0.5 transition-colors ${
                      currentUser.readReceipts ? 'bg-[#00a884]' : 'bg-slate-600'
                    }`}
                  >
                    <div
                      className={`bg-white w-4 h-4 rounded-full shadow transform transition-transform ${
                        currentUser.readReceipts ? 'translate-x-4' : 'translate-x-0'
                      }`}
                    />
                  </div>
                </div>
              </div>

              {/* Reset to Initial Demo Data */}
              <div className="pt-4 border-t border-slate-700/30">
                <button
                  type="button"
                  onClick={() => {
                    if (confirm('Reset all chats, status updates, and settings to original state?')) {
                      onResetData();
                    }
                  }}
                  className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl border border-rose-500/30 text-rose-400 hover:bg-rose-500/10 text-xs font-semibold transition-colors"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Reset Demo Data</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Profile Avatar Picker Modal */}
      {isProfileAvatarPickerOpen && (
        <AvatarPickerModal
          title="Profile Photo"
          currentAvatar={currentUser.avatar}
          initialsFallback={currentUser.name[0]}
          theme={theme}
          onClose={() => setIsProfileAvatarPickerOpen(false)}
          onSaveAvatar={(newAvatar) => {
            onUpdateProfile({ avatar: newAvatar });
          }}
          onRemoveAvatar={() => {
            onUpdateProfile({ avatar: '' });
          }}
        />
      )}
    </div>
  );
};
